#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i;
	s[1]='S';
	s[2]='T';
	s[3]='A';
	s[4]='R';
	s[5]='P';
	s[6]='R';
	s[7]='O';
	s[8]='J';
	s[9]='E';
	s[10]='C';
	s[11]='T';
	s[0]='*';
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	printf("\n");


	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nConfirm ");	
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='&';
	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nConfirm ");	
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='^';
	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nConfirm ");	
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='^';
	
	
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	s[1]='U';
	s[2]='T';
	s[3]='1';
	s[4]=' ';
	s[5]='U';
	s[6]='T';
	s[7]='2';
	s[8]=' ';
	s[9]='U';
	s[10]='T';
	s[11]='3';
	s[0]='%';
	while(s[0]!='^'){
		sleep(1);
	}
		shmctl(shmid, IPC_RMID, NULL);	

}

