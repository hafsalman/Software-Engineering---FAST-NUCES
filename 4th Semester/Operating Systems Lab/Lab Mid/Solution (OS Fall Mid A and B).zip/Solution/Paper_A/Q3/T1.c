#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i;
	printf("\nReceived ");
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	printf("\n");
	

	while(s[0]!='%'){
		sleep(1);
	}
	
	printf("Task 1 Done\n");
	s[1]='T';
	s[2]='A';
	s[3]='S';
	s[4]='K';
	s[5]=' ';
	s[6]='1';
	s[7]=' ';
	s[8]='D';
	s[9]='O';
	s[10]='N';
	s[11]='E';
	s[0]='$';
	
	while(s[0]!='%'){
		sleep(1);
	}
	printf("\n");
	for(i=1;i<=3;i++){
		putchar(s[i]);
	}
	
}

