
# Greet user with their roll number
read -p "Enter your roll number: " roll_number
echo "Hello, your roll number is $roll_number."

# Ask the user how many folders they want to create
read -p "How many folders do you want to create? " num_folders

# Create the folders with special characters
echo "Creating $num_folders folders..."
for (( i=1; i<=num_folders; i++ ))
do
    folder_name="%Folder_$i"
    mkdir "$folder_name"
    echo "Created folder: $folder_name"
done

# Navigate to a folder and create the C file
cd "%Folder_1"


cat <<EOF > factorial.c
#include <stdio.h>

int factorial(int n) {
    if (n <= 1)
        return 1;
    else
        return n * factorial(n - 1);
}

int main() {
    int num;
    printf("Enter a number to calculate its factorial: ");
    scanf("%d", &num);
    printf("Factorial of %d is: %d\\n", num, factorial(num));
    return 0;
}
EOF

echo "Created factorial.c in %Folder_1"

# Compile and run the C file
gcc factorial.c -o factorial
echo "Compiling factorial.c..."
echo "Running the compiled program..."
./factorial

# Copy the C file to the Desktop and clean up folders
desktop_path=~/Desktop
cp factorial.c "$desktop_path"
echo "Copied factorial.c to Desktop."

# Delete all folders except the one with the .C file
cd ..
for (( i=2; i<=num_folders; i++ ))
do
    rm -rf "%Folder_$i"
    echo "Deleted folder: %Folder_$i"
done

# Delete the .C file from the original folder
cd "%Folder_1"
rm factorial.c
echo "Deleted factorial.c from %Folder_1."

echo "Script execution completed."
