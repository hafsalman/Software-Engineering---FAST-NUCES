#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i;
	printf("\nReceived ");
	for(i=1;i<=5;i++){
		putchar(s[i]);
	}
	printf("\n");
	

	while(s[0]!='%'){
		sleep(1);
	}
	
	printf("World\n");
	s[1]='W';
	s[2]='O';
	s[3]='R';
	s[4]='L';
	s[5]='D';
	s[0]='$';
	
	while(s[0]!='%'){
		sleep(1);
	}
	printf("\nReceived Hello ");
	for(i=1;i<=2;i++){
		putchar(s[i]);
	}
	
}

