#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i;
	printf("\nReceived ");
	for(i=1;i<=5;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='%';

	while(s[0]!='^'){
		sleep(1);
	}
	printf("\nOS\n");
	s[1]='O';
	s[2]='S';
	
	s[0]='$';
	while(s[0]!='%'){
		sleep(1);
	}
	printf("\nReceived Hello ");
	for(i=5;i<=6;i++){
		putchar(s[i]);
	}
	s[0]='^';
	
}

