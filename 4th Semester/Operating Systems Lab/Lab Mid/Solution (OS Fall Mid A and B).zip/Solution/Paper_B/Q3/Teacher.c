#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i;
	s[1]='H';
	s[2]='E';
	s[3]='L';
	s[4]='L';
	s[5]='O';
	s[0]='*';
	for(i=1;i<=5;i++){
		putchar(s[i]);
	}
	printf("\n");


	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nReceived ");	
	for(i=1;i<=5;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='&';
	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nReceived ");	
	for(i=1;i<=5;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='^';
	while(s[0]!='$'){
		sleep(1);
	}
	printf("\nReceived ");	
	for(i=1;i<=2;i++){
		putchar(s[i]);
	}
	printf("\n");
	s[0]='^';
	
	
	for(i=1;i<=11;i++){
		putchar(s[i]);
	}
	s[1]='S';
	s[2]='1';
	s[3]='S';
	s[4]='2';
	s[5]='S';
	s[6]='3';
	s[0]='%';
	while(s[0]!='^'){
		sleep(1);
	}
		shmctl(shmid, IPC_RMID, NULL);	

}

