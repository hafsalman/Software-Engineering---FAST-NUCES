
# 1. Find all the .C files in the current directory
echo "Finding all .C files in the current directory..."
c_files=$(find . -type f -name "*.c")

# 2. Compile each .C file and append the output to a text file
output_file="compile_output.txt"
> $output_file  # Clear the output file if it already exists
for file in $c_files
do
    echo "Compiling $file..."
    gcc "$file" -o "${file%.c}.out" 2>> $output_file
    if [[ $? -eq 0 ]]; then
        echo "Compilation of $file successful." >> $output_file
    else
        echo "Compilation of $file failed." >> $output_file
    fi
done

echo "Compilation results are saved in $output_file."

# 3. Launch File2.sh
echo "Launching File2.sh..."
./File2.sh
