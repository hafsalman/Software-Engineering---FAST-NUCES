
# Create a new C file that handles file copying
cat <<EOF > file_copy.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

// Function to copy a file Note it doesn't have to be the same implementation 
void copyFile(const char *src, const char *dest) {
    FILE *sourceFile, *destFile;
    sourceFile = fopen(src, "rb");
    if (sourceFile == NULL) {
        perror("Error opening source file");
        return;
    }
    
    destFile = fopen(dest, "wb");
    if (destFile == NULL) {
        perror("Error opening destination file");
        fclose(sourceFile);
        return;
    }

    char buffer[1024];
    size_t bytesRead;
    while ((bytesRead = fread(buffer, 1, sizeof(buffer), sourceFile)) > 0) {
        fwrite(buffer, 1, bytesRead, destFile);
    }

    fclose(sourceFile);
    fclose(destFile);
    printf("Copied %s to %s\\n", src, dest);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Usage: %s <extension> <destination_directory>\\n", argv[0]);
        return 1;
    }

    char *extension = argv[1];
    char *destDir = argv[2];

    // Create the destination directory if it doesn't exist
    if (mkdir(destDir, 0755) != 0 && errno != EEXIST) {
        perror("Failed to create directory");
        return 1;
    }

    // Open the current directory
    DIR *dir = opendir(".");
    if (dir == NULL) {
        perror("Could not open current directory");
        return 1;
    }

    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
        // Check if the file ends with the specified extension
        if (strstr(entry->d_name, extension) != NULL) {
            char destPath[256];
            snprintf(destPath, sizeof(destPath), "%s/%s", destDir, entry->d_name);
            copyFile(entry->d_name, destPath);
        }
    }

    closedir(dir);
    return 0;
}
EOF

# Compile the C program that handles file copying
echo "Compiling file_copy.c..."
gcc file_copy.c -o file_copy

# Inform the user to run the executable
echo "Compilation of file_copy.c complete. Run the program using:"
echo "./file_copy <file_extension> <destination_directory>"
