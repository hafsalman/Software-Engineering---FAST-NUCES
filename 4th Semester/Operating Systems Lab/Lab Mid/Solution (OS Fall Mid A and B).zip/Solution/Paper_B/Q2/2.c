#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<sys/wait.h>

#define MAXSIZE 27

int main(void) {
	char c;
	int shmid,final_value=0;
	key_t key;
	char *shm, *s;

	key = 2222;
	shmid = shmget(key, MAXSIZE, IPC_CREAT | 0666);
	shm = shmat(shmid, NULL, 0);
	s = shm;
	int i=fork();
	if(i==0){
		i=fork();
		if(i==0){
			s[0]='2';
		}else{
			wait(NULL);
			i=fork();
			if(i==0){
				s[1]='3';
				
			}else{
				wait(NULL);
				
			}
			final_value=(s[0]-'0')-(s[1]-'0');
			
			s[2]=final_value+'0';
		}
	}else{
		wait(NULL);
		i=fork();
		if(i==0){
			s[3]='7';
			exit(0);
		}else{
			wait(NULL);
			i=fork();
			if(i==0){
				s[5]='4';
				exit(0);
			}else{
				wait(NULL);
				i=fork();
				if(i==0){
					s[6]='5';
					
				}else{
					wait(NULL);
					exit(0);
					
				}
				final_value=(s[5]-'0')-(s[6]-'0');
				s[4]=final_value+'0';
			}
		}
		
		final_value=(s[2]-'0')-(s[3]-'0')-(s[4]-'0');
		printf("%d",final_value);
	}
		
		shmctl(shmid, IPC_RMID, NULL);	

}

