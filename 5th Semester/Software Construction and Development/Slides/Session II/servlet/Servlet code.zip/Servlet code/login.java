import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

    private static final String[] names = {"john", "doe"};
    private static final String[] passwords = {"john123", "doe123"};

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        boolean isValidUser = false;

        for (int i = 0; i < names.length; i++) {
            if (name.equals(names[i]) && password.equals(passwords[i])) {
                isValidUser = true;
                break;
            }
        }

        if (isValidUser) {
            response.sendRedirect("EmployeeServlet");
        } else {
            PrintWriter out = response.getWriter();
            out.println("<html><body><h3>Invalid credentials, please try again.</h3></body></html>");
        }
    }
}
