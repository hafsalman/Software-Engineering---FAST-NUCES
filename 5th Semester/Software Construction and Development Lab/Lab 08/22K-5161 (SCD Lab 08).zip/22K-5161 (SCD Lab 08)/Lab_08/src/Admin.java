//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;

public class Admin extends JFrame
{
    private JPanel Admin;
    private JLabel Adminn;
    private JButton manageUsersButton;

    public Admin ()
    {
        setTitle("22K-5161 (Task no. 02)");
        setSize(500, 500);
        setContentPane(Admin);
        setVisible(true);
    }
}