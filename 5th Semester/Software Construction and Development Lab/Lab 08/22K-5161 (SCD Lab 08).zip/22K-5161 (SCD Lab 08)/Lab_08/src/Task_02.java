//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_02 extends JFrame
{
    private JPanel Task_02;
    private JLabel Label_01;
    private JButton createAccountButton;
    private JButton manageUsersButton;

    public Task_02()
    {
        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Create_account();
            }
        });

        manageUsersButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Login_page();
            }
        });
    }

    public static void main(String[] args)
    {
        Task_02 T2 = new Task_02();
        T2.setContentPane(T2.Task_02);
        T2.setTitle("22K-5161");
        T2.setSize(500, 500);
        T2.setVisible(true);

        T2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}