//Hafsa Salman
//22K-5161
//DatabaseUtil Class

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil
{
    public static final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    public static final String USER = "system";
    public static final String PASS = "abc123";

    public static Connection getConnection() throws SQLException
    {
        return DriverManager.getConnection(JDBC_URL, USER, PASS);
    }

    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("DatabaseUtil Class");
        System.out.println();

        Connection connection = null;

        try
        {
            connection = getConnection();

            if (connection != null)
            {
                System.out.println("Connection Successful!");
            }
        }

        catch (SQLException e)
        {
            System.out.println("Connection Failed!");

            e.printStackTrace();
        }

        finally
        {
            if (connection != null)
            {
                try
                {
                    connection.close();
                }

                catch (SQLException e)
                {
                    System.out.println("Failed to close the connection!");

                    e.printStackTrace();
                }
            }
        }
    }
}