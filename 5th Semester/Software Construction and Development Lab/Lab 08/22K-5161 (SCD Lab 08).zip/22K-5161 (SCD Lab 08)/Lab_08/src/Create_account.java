// Hafsa Salman
// 22K-5161
// Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Create_account extends JFrame
{
    private JPanel CreateAccount;
    private JLabel Label01;
    private JTextField NameTxt;
    private JLabel Name;
    private JLabel UserID;
    private JTextField IDTxt;
    private JLabel Email;
    private JTextField EmailTxt;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
    private JLabel Pass01;
    private JLabel Pass02;
    private JLabel DOBTxt;
    private JTextField textField1;
    private JButton createAccountButton;

    public Create_account()
    {
        setTitle("22K-5161 (Task no. 02)");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(CreateAccount);
        setVisible(true);

        IDTxt.addFocusListener(new FocusAdapter()
        {
            @Override
            public void focusLost(FocusEvent e)
            {
                String id = IDTxt.getText();
                if (!id.isEmpty() && UserID(id))
                {
                    JOptionPane.showMessageDialog(Create_account.this, "UserID already exists! Please choose a different one.");
                    IDTxt.requestFocus();
                }
            }
        });

        EmailTxt.addFocusListener(new FocusAdapter()
        {
            @Override
            public void focusLost(FocusEvent e)
            {
                String email = EmailTxt.getText();
                if (!email.isEmpty() && isEmailTaken(email))
                {
                    JOptionPane.showMessageDialog(Create_account.this, "Email already exists! Please use a different email.");
                    EmailTxt.requestFocus();
                }
            }
        });

        createAccountButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String id = IDTxt.getText();
                String fullName = NameTxt.getText();
                String email = EmailTxt.getText();
                String password = new String(passwordField1.getPassword());
                String confirmPassword = new String(passwordField2.getPassword());
                String birth = DOBTxt.getText();  // No format checking

                if (validateInput(id, fullName, email, password, confirmPassword))
                {
                    createAccount(id, fullName, email, password, birth);
                }
            }
        });
    }

    private boolean UserID(String id)
    {
        try (Connection conn = DatabaseUtil.getConnection())
        {
            String query = "SELECT ID FROM TASK_02 WHERE ID = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            return rs.next();
        }
        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this, "Error checking UserID: " + e.getMessage());
        }

        return false;
    }

    private boolean isEmailTaken(String email)
    {
        try (Connection conn = DatabaseUtil.getConnection())
        {
            String query = "SELECT EMAIL FROM TASK_02 WHERE EMAIL = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            return rs.next();
        }

        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this, "Error checking Email: " + e.getMessage());
        }

        return false;
    }

    private boolean validateInput(String id, String fullName, String email, String password, String confirmPassword)
    {
        if (id.isEmpty() || fullName.isEmpty() || email.isEmpty() || password.isEmpty())
        {
            JOptionPane.showMessageDialog(this, "All fields are required!");

            return false;
        }

        if (!password.equals(confirmPassword))
        {
            JOptionPane.showMessageDialog(this, "Passwords do not match!");

            return false;
        }

        return true;
    }

    private void createAccount(String id, String fullName, String email, String password, String birth)
    {
        try (Connection conn = DatabaseUtil.getConnection())
        {
            String query = "INSERT INTO TASK_02 (ID, FULL_NAME, EMAIL, PASSWORD, BIRTH, USER_ROLE) VALUES (?, ?, ?, ?, ?, 'USER')";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, id);
            ps.setString(2, fullName);
            ps.setString(3, email);
            ps.setString(4, password);
            ps.setString(5, birth);

            ps.executeUpdate();

            JOptionPane.showMessageDialog(this, "Account created successfully!");
        }

        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this, "Account creation error: " + e.getMessage());
        }
    }
}