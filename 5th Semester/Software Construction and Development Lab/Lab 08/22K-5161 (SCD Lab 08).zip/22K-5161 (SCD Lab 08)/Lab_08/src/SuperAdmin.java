//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;

public class SuperAdmin extends JFrame
{
    private JLabel Welcome;
    private JButton manageUsersButton;
    private JButton manageAdminsButton;
    private JPanel SA;

    public SuperAdmin ()
    {
        setTitle("22K-5161 (Task no. 02)");
        setSize(500, 500);
        setContentPane(SA);
        setVisible(true);
    }
}