//Hafsa Salman
//22K-5161
//Task no. 01

import java.sql.*;
import java.util.Scanner;

public class Task_01
{
    public static void Insert (String ID, String full_name, String email, String password, String birth)
    {
        String query = "INSERT INTO USERS (ID, FULL_NAME, EMAIL, PASSWORD, BIRTH, USER_ROLE, ACCOUNT_CREATION) VALUES (?, ?, ?, ?, TO_DATE(?, 'DD-MM-YYYY'), 'User', SYSTIMESTAMP)";

        try (Connection connection = DatabaseUtil.getConnection())
        {
            PreparedStatement statement = connection.prepareStatement(query);

            statement.setString(1, ID);
            statement.setString(2, full_name);
            statement.setString(3, email);
            statement.setString(4, password);
            statement.setString(5, birth);

            int rowsAffected = statement.executeUpdate();

            System.out.println();
            System.out.println("\u001B[32m" + rowsAffected + " row(s) inserted!\u001B[0m");
            System.out.println();
        }

        catch (SQLException e)
        {
            System.out.println("Connection or insertion has failed!");

            e.printStackTrace();
        }
    }

    public static void Update (String ID, String attribute, String str)
    {
        if (attribute.equals("ID"))
        {
            System.out.println("ID can not be changed!");
        }

        else if (attribute.equals("Name") || attribute.equals("name") || attribute.equals("NAME"))
        {
            String query = "UPDATE USERS SET FULL_NAME = ? WHERE ID = ?";

            try (Connection connection = DatabaseUtil.getConnection())
            {
                PreparedStatement statement = connection.prepareStatement(query);

                statement.setString(1, str);
                statement.setString(2, ID);

                int rowsAffected = statement.executeUpdate();

                System.out.println();
                System.out.println("\u001B[32m" + rowsAffected + " row(s) updated!\u001B[0m");
                System.out.println();
            }

            catch (SQLException e)
            {
                System.out.println("Connection or update has failed!");
            }
        }

        else if (attribute.equals("Email") || attribute.equals("email") || attribute.equals("EMAIL"))
        {
            String query = "UPDATE USERS SET EMAIL = ? WHERE ID = ?";

            try (Connection connection = DatabaseUtil.getConnection())
            {
                PreparedStatement statement = connection.prepareStatement(query);

                statement.setString(1, str);
                statement.setString(2, ID);

                int rowsAffected = statement.executeUpdate();

                System.out.println();
                System.out.println("\u001B[32m" + rowsAffected + " row(s) updated!\u001B[0m");
                System.out.println();
            }

            catch (SQLException e)
            {
                System.out.println("Connection or update has failed!");
            }
        }

        else if (attribute.equals("Password") || attribute.equals("password") || attribute.equals("PASSWORD"))
        {
            String query = "UPDATE USERS SET PASSWORD = ? WHERE ID = ?";

            try (Connection connection = DatabaseUtil.getConnection())
            {
                PreparedStatement statement = connection.prepareStatement(query);

                statement.setString(1, str);
                statement.setString(2, ID);

                int rowsAffected = statement.executeUpdate();

                System.out.println();
                System.out.println("\u001B[32m" + rowsAffected + " row(s) updated!\u001B[0m");
                System.out.println();
            }

            catch (SQLException e)
            {
                System.out.println("Connection or update has failed!");
            }
        }

        else if (attribute.equals("Date of Birth") || attribute.equals("date of birth") || attribute.equals("DATE OF BIRTH"))
        {
            String query = "UPDATE USERS SET BIRTH = ? WHERE ID = ?";

            try (Connection connection = DatabaseUtil.getConnection())
            {
                PreparedStatement statement = connection.prepareStatement(query);

                statement.setString(1, str);
                statement.setString(2, ID);

                int rowsAffected = statement.executeUpdate();

                System.out.println();
                System.out.println("\u001B[32m" + rowsAffected + " row(s) updated!\u001B[0m");
                System.out.println();
            }

            catch (SQLException e)
            {
                System.out.println("Connection or update has failed!");
            }
        }

        else
        {
            System.out.println("Invalid Choice!");
        }
    }

    public static void Delete (String ID)
    {
        String query = "DELETE FROM USERS WHERE ID = ?";

        try (Connection connection = DatabaseUtil.getConnection())
        {
            PreparedStatement statement = connection.prepareStatement(query);

            statement.setString(1, ID);

            int rowsAffected = statement.executeUpdate();

            System.out.println();
            System.out.println("\u001B[32m" + rowsAffected + " row(s) deleted!\u001B[0m");
            System.out.println();
        }

        catch (SQLException e)
        {
            System.out.println("Connection or deletion has failed!");
        }
    }

    public static void Display ()
    {
        try (Connection connection = DatabaseUtil.getConnection())
        {
            Statement statement = connection.createStatement();

            String query = "SELECT * FROM USERS";

            ResultSet rs = statement.executeQuery(query);

            System.out.println("ID\tFULL_NAME\tEMAIL\tPASSWORD\tDATE OF BIRTH\tUSER_ROLE\tACCOUNT_CREATION" );
            System.out.println("------------------------------------------------------");

            while (rs.next())
            {
                String ID = rs.getString("ID");
                String full_name = rs.getString("FULL_NAME");
                String email = rs.getString("EMAIL");
                String password = rs.getString("PASSWORD");
                String birth = rs.getString("BIRTH");
                String user_role = rs.getString("USER_ROLE");
                String account = rs.getString("ACCOUNT_CREATION");

                System.out.println(ID + "\t" + full_name  + "\t" + email  + "\t" + password + "\t" + birth + "\t" + user_role + "\t" + account);
                System.out.println();
            }
        }

        catch (SQLException e)
        {
            System.out.println("Connection or query has failed!");
        }
    }

    public static void main(String[] args)
    {
        System.out.println("\u001B[34mName: Hafsa Salman\u001B[0m");
        System.out.println("\u001B[34mRoll no. 22K-5161\u001B[0m");
        System.out.println("\u001B[34mTask no. 01\u001B[0m");
        System.out.println();

        Scanner s = new Scanner(System.in);

        int choice;

        do
        {
            System.out.println("Options: ");
            System.out.println("1. Insert User");
            System.out.println("2. Update User");
            System.out.println("3. Delete User");
            System.out.println("4. Display User");
            System.out.println("5. Exit");

            System.out.print("Enter your choice: ");
            choice = s.nextInt();

            s.nextLine();

            System.out.println();

            String ID, full_name, email, password, birth;

            switch(choice)
            {
                case 1:
                {
                    System.out.print("Enter ID: ");
                    ID = s.nextLine();

                    System.out.print("Enter Full Name: ");
                    full_name = s.nextLine();

                    System.out.print("Enter Email: ");
                    email = s.nextLine();

                    System.out.print("Enter Password: ");
                    password = s.nextLine();

                    System.out.print("Enter Birth (DD-MM-YYYY): ");
                    birth = s.nextLine();

                    Insert(ID, full_name, email, password, birth);
                }

                break;

                case 2:
                {
                    System.out.print("Enter ID of the user to update: ");
                    ID = s.nextLine();

                    System.out.print("Enter the attribute (name, email, password, birth) you want to update: ");
                    String attribute = s.nextLine();

                    System.out.print("Enter " + attribute + ": ");
                    String value = s.nextLine();

                    Update(ID, attribute, value);
                }

                break;

                case 3:
                {
                    System.out.print("Enter ID of the user to delete: ");
                    ID = s.nextLine();

                    Delete(ID);
                }

                break;

                case 4:
                {
                    Display();
                }

                break;

                default:
                {
                    System.out.println("Invalid input!");
                }

                break;
            }
        }
        while (choice != 5);

        s.close();
    }
}