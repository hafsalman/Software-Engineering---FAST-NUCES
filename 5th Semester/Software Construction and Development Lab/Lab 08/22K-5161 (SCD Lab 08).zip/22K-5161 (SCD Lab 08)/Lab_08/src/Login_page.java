//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Login_page extends JFrame
{
    private JTextField IDTxt;
    private JButton loginButton;
    private JLabel Heading;
    private JLabel UserID;
    private JLabel Pass;
    private JPasswordField passwordField1;
    private JPanel Login;

    public Login_page()
    {
        setTitle("22K-5161 (Task no. 02)");
        setSize(500, 500);
        setContentPane(Login);
        setVisible(true);

        loginButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String userID = IDTxt.getText();
                String password = new String(passwordField1.getPassword());

                if (userID.isEmpty() || password.isEmpty())
                {
                    JOptionPane.showMessageDialog(Login_page.this, "Please fill in both fields.");
                }

                else
                {
                    if (authenticateUser(userID, password))
                    {
                        new SuperAdmin();
                    }

                    else
                    {
                        JOptionPane.showMessageDialog(Login_page.this, "Invalid User ID or Password.");
                    }
                }
            }
        });
    }

    private boolean authenticateUser(String userID, String password)
    {
        try (Connection conn = DatabaseUtil.getConnection())
        {
            String query = "SELECT ID, PASSWORD FROM TASK_02 WHERE ID = ? AND PASSWORD = ?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, userID);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();
            return rs.next();

        }

        catch (SQLException e)
        {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage());
        }

        return false;
    }
}