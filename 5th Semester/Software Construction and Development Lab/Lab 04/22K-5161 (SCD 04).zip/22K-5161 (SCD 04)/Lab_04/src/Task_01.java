//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class Task_01 extends JFrame
{
    private JPanel Task_01A;
    private JLabel Name;
    private JLabel FatherName;
    private JLabel CNIC;
    private JLabel PNo;
    private JLabel Pass1;
    private JLabel Pass2;
    private JLabel Gender;
    private JLabel Nationality;
    private JLabel Email;
    private JTextField NameTxt;
    private JTextField FNameTxt;
    private JTextField CnicTxt;
    private JTextField PnoTxt;
    private JPasswordField Pass1Txt;
    private JPasswordField Pass2Txt;
    private JComboBox GenderTxt;
    private JTextField NationalityTxt;
    private JTextField EmailTxt;
    private JButton btn;

    public Task_01()
    {
        btn.addActionListener( new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String n = NameTxt.getText();
                String fn = FNameTxt.getText();
                String Cnic = CnicTxt.getText();
                String Pno = PnoTxt.getText();

                char[] p1 = Pass1Txt.getPassword();
                String Pa1 = new String(p1);

                char[] p2 = Pass2Txt.getPassword();
                String Pa2 = new String(p2);

                String g = (String) GenderTxt.getSelectedItem();

                String Nation = NationalityTxt.getText();
                String E = EmailTxt.getText();

                if (Objects.equals(n, null))
                {
                    JOptionPane.showMessageDialog(btn, "Name Field is empty!");
                }

                else if (Objects.equals(fn, null))
                {
                    JOptionPane.showMessageDialog(btn, "Father's Name Field is empty!");
                }

                else if (Objects.equals(Cnic, null))
                {
                    JOptionPane.showMessageDialog(btn, "CNIC Field is empty!");
                }

                else if (Objects.equals(Pno, null))
                {
                    JOptionPane.showMessageDialog(btn, "Phone Number Field is empty!");
                }

                else if (Objects.equals(Pa1, null))
                {
                    JOptionPane.showMessageDialog(btn, "Password Field is empty!");
                }

                else if (Objects.equals(Pa2, null))
                {
                    JOptionPane.showMessageDialog(btn, "Re-enter Password Field is empty!");
                }

                else if (Objects.equals(Nation, null))
                {
                    JOptionPane.showMessageDialog(btn, "Nationality field is empty!");
                }

                else if (Objects.equals(g, "--"))
                {
                    JOptionPane.showMessageDialog(btn, "Gender field is empty!");
                }

                else if (Objects.equals(E, null))
                {
                    JOptionPane.showMessageDialog(btn, "Email field is empty!");
                }

                else if (!Objects.equals(Pa1, Pa2))
                {
                    JOptionPane.showMessageDialog(btn, "Password and Re-entered password are not same!");
                }

                else
                {
                    new Task_01B(n, fn, Cnic, Pno, g, Nation, E);
                    dispose();
                }
            }
        });
    }

    public static void main(String[] args)
    {
        Task_01 T1 = new Task_01();

        T1.setContentPane(T1.Task_01A);
        T1.setTitle("Registration Form (22K-5161)");
        T1.setSize(500, 500);
        T1.setVisible(true);

        T1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}