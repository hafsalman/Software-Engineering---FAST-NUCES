//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_03 extends JFrame
{
    private JPanel Task_03;
    private JLabel Acc;
    private JTextField AccTxt;
    private JPasswordField PassTxt;
    private JLabel Pass;
    private JButton Btn;

    public Task_03()
    {
        Btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (AccTxt.getText().equals("123456789") && PassTxt.getText().equals("0123"))
                {
                    new Task_03B();
                    dispose();
                }

                else
                {
                    JOptionPane.showMessageDialog(Btn, "Invalid Account No. or Password!");
                }
            }
        });
    }

    public static void main(String[] args)
    {
        Task_03 T3 = new Task_03();
        T3.setContentPane(T3.Task_03);
        T3.setTitle("ATM (22K-5161)");
        T3.setSize(500, 500);
        T3.setVisible(true);

        T3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}