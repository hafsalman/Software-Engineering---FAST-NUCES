//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_03D extends JFrame
{
    private JPanel Task_03D;
    private JLabel Withdraw;
    private JTextField WDTxt;
    private JButton btn;

    public Task_03D(int amount)
    {
        setContentPane(Task_03D);
        setTitle("ATM (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final int[] Amount = {amount};

        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int am = Integer.parseInt(WDTxt.getText());

                if (am < 0)
                {
                    JOptionPane.showMessageDialog(btn, "Please enter valid amount!");
                }
                else
                {
                    Amount[0] = Amount[0] - am;

                    JOptionPane.showMessageDialog(btn, "Withdrawn successful!" + "\nCurrent balance: " + Amount[0]);
                    dispose();
                }
            }
        });
    }
}