//Hafsa Salman
//22K-5161
//Task no. 05

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Task_05 extends JFrame
{
    private JLabel Txt;
    private JTextArea TxtArea;
    private JButton btn;
    private JPanel Task_05;
    private JComboBox comboBox1;
    private JTextArea textArea1;

    public Task_05()
    {
        TxtArea.addKeyListener(new KeyAdapter()
        {
            @Override
            public void keyReleased(KeyEvent e)
            {
                String Input = TxtArea.getText();
                Transformation (Input);
            }
        });

        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String Input = TxtArea.getText();
                Transformation (Input);
            }
        });
    }

    public void Transformation (String Input)
    {
        if (Input.isEmpty())
        {
            JOptionPane.showMessageDialog (null, "Please enter a text to transformation");
        }

        String select = (String) comboBox1.getSelectedItem();
        String meow;

        if (select.equals("Uppercase"))
        {
            meow = Input.toUpperCase();
            textArea1.setText(meow);
        }

        else if (select.equals("Reverse"))
        {
            meow = new StringBuilder(Input).reverse().toString();
            textArea1.setText(meow);
        }

        else if (select.equals("Underscores"))
        {
            meow = Input.replace(" ", "_");
            textArea1.setText(meow);
        }
    }

    public static void main(String[] args)
    {
        Task_05 T5 = new Task_05();

        T5.setContentPane(T5.Task_05);
        T5.setTitle("Transformation of Text (22K-5161)");
        T5.setSize(500, 500);
        T5.setVisible(true);

        T5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}