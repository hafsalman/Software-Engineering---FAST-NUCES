//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_03C extends JFrame
{
    private JPanel Task_03C;
    private JLabel Deposit;
    private JTextField Dep;
    private JButton btn;

    public Task_03C(int initialAmount)
    {
        setContentPane(Task_03C);
        setTitle("ATM (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        final int[] amount = {initialAmount};

        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                int am = Integer.parseInt(Dep.getText());

                if (am < 0)
                {
                    JOptionPane.showMessageDialog(btn, "Please enter valid amount!");
                }
                else
                {
                    amount[0] = amount[0] + am;

                    JOptionPane.showMessageDialog(btn, "Deposit successful!" + "\nCurrent balance: " + amount[0]);
                    dispose();
                }
            }
        });
    }
}