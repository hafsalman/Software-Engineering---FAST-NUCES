//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_01B extends JFrame
{
    private JPanel Task_01B;
    private JTextArea Meow;
    private JButton btn;

    public Task_01B(String Name, String Father, String CNIC, String Phone, String Gender, String Nationality, String Email)
    {
        setContentPane(Task_01B);
        setTitle("Registration Form (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Meow.setText("Name: " + Name + "\nFather Name: " + Father + "\nCNIC: " + CNIC + "\nPhone No.: " + Phone + "\nGender: " + Gender + "\nNationality: " + Nationality + "\nEmail: " + Email);


        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dispose();
            }
        });
    }
}