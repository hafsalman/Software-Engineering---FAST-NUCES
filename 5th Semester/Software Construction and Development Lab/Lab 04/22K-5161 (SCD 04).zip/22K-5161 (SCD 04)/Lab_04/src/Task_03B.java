//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_03B extends JFrame
{
    private JLabel Whe;
    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JButton btn4;
    private JPanel Task_03B;

    final static int amount = 5000;

    public Task_03B()
    {
        setContentPane(Task_03B);
        setTitle("ATM (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Amount Balance
        btn1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(btn1, "Current Balance: " + amount);
            }
        });

        //Deposit Money
        btn2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Task_03C(amount);
                dispose();
            }
        });

        //Withdraw Money
        btn3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Task_03D(amount);
                dispose();
            }
        });

        //Exit
        btn4.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(btn4, "Exited Successfully");
                dispose();
            }
        });
    }
}