//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class Task_02 extends JFrame
{
    private JPanel Task_02;
    private JLabel Alpha;
    private JTextField KeyTxt;
    private JTextArea Well;
    private JButton Btn;


    public Task_02()
    {
        KeyTxt.addKeyListener(new KeyAdapter()
        {
            @Override
            public void keyTyped(KeyEvent e)
            {
                super.keyTyped(e);

                char ch = e.getKeyChar();
                int value = (int) ch;

                Well.setText("Typed Alphabet: " + ch + "\nASCII: " + value);
            }
        });

        Btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                dispose();
            }
        });
    }

    public static void main(String[] args)
    {
        Task_02 T2 = new Task_02();

        T2.setContentPane(T2.Task_02);
        T2.setTitle("ASCII Code (22K-5161)");
        T2.setSize(300, 300);
        T2.setLocationRelativeTo(null);
        T2.setVisible(true);

        T2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}