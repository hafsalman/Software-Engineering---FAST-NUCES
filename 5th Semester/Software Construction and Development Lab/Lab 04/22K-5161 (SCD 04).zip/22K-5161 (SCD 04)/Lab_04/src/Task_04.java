//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Task_04 extends JFrame
{
    private JPanel Task_04;
    private JLabel SDetails;
    private JLabel Name;
    private JTextField NameTxt;
    private JLabel Roll;
    private JTextField RollTxt;
    private JLabel Class;
    private JTextField ClassTxt;
    private JLabel Grade;
    private JLabel Course1;
    private JLabel Calculus_Grade;
    private JTextField textField1;
    private JTextField textField2;
    private JLabel Calculus_CrHr;
    private JLabel English;
    private JLabel English_Grade;
    private JTextField textField3;
    private JTextField textField4;
    private JLabel English_CrHr;
    private JLabel PF;
    private JTextField textField5;
    private JLabel PF_CrHr;
    private JLabel PF_Grade;
    private JTextField textField6;
    private JButton btn1;
    private JButton btn2;
    private JButton btn3;
    private JLabel SGPAvalue;
    private JLabel SGPA;


    public Task_04()
    {
        btn1.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (isInputValid())
                {
                    ArrayList<Double> grades = new ArrayList<>();
                    grades.add(Double.parseDouble(textField1.getText()));
                    grades.add(Double.parseDouble(textField3.getText()));
                    grades.add(Double.parseDouble(textField5.getText()));
                    ArrayList<Integer> credits = new ArrayList<>();
                    credits.add(Integer.parseInt(textField2.getText()));
                    credits.add(Integer.parseInt(textField4.getText()));
                    credits.add(Integer.parseInt(textField6.getText()));

                    double sgpa = calculateSGPA(grades, credits);
                    String remark = getPerformanceRemark(sgpa);

                    SGPAvalue.setText(Double.toString(sgpa));
                }

                else
                {
                    JOptionPane.showMessageDialog(null, "Invalid Input!");
                }
            }
        });

        btn2.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (isInputValid())
                {
                    ArrayList<Double> grades = new ArrayList<>();
                    grades.add(Double.parseDouble(textField1.getText()));
                    grades.add(Double.parseDouble(textField3.getText()));
                    grades.add(Double.parseDouble(textField5.getText()));
                    ArrayList<Integer> credits = new ArrayList<>();
                    credits.add(Integer.parseInt(textField2.getText()));
                    credits.add(Integer.parseInt(textField4.getText()));
                    credits.add(Integer.parseInt(textField6.getText()));

                    double sgpa = calculateSGPA(grades, credits);
                    String remark = getPerformanceRemark(sgpa);

                    JOptionPane.showMessageDialog(null, "Calculus: \nGrade: " + textField1.getText() + "\nCredit hrs: " + textField2.getText() + "\nEnglish: \nGrade: " + textField3.getText() + "\nCredit hrs: " + textField4.getText() + "\nProgramming Fundamentals: \nGrade: " + textField5.getText() + "\nCredit hrs: " + textField6.getText() + "\nSGPA: " + sgpa + "\nRemarks: " + remark);
                }

                else
                {
                    JOptionPane.showMessageDialog(null, "Invalid input!");
                }

            }
        });
        btn3.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                NameTxt.setText("");
                RollTxt.setText("");
                ClassTxt.setText("");
                textField1.setText("");
                textField2.setText("");
                textField3.setText("");
                textField4.setText("");
                textField5.setText("");
                textField6.setText("");
                SGPAvalue.setText("");
            }
        });
    }

    private double calculateSGPA (ArrayList<Double> grades, ArrayList<Integer> credits)
    {
        double totalPoints = 0;
        int totalCredits = 0;

        for (int i = 0; i < grades.size(); i++)
        {
            totalPoints += grades.get(i) * credits.get(i);
            totalCredits += credits.get(i);
        }

        return totalPoints / totalCredits;
    }

    private String getPerformanceRemark(double sgpa)
    {
        if (sgpa >= 9)
        {
            return "Excellent";
        }

        else if (sgpa >= 3.5)
        {
            return "Very Good";
        }

        else if (sgpa >= 3)
        {
            return "Good";
        }

        else if (sgpa >= 2.5)
        {
            return "Satisfactory";
        }

        else
        {
            return "Needs Improvement";
        }
    }
    private boolean isInputValid()
    {
        try
        {
            if (textField1.getText().isEmpty() || textField2.getText().isEmpty() || textField3.getText().isEmpty() || textField4.getText().isEmpty() || textField5.getText().isEmpty() || textField6.getText().isEmpty())
            {
                return false;
            }

            Double.parseDouble(textField1.getText());
            Double.parseDouble(textField3.getText());
            Double.parseDouble(textField5.getText());
            Integer.parseInt(textField2.getText());
            Integer.parseInt(textField4.getText());
            Integer.parseInt(textField6.getText());

        }

        catch (NumberFormatException ex)
        {
            return false;
        }

        return true;
    }

    public static void main(String[] args)
    {
        Task_04 T4 = new Task_04();

        T4.setContentPane(T4.Task_04);
        T4.setTitle("SGPA (22K-5161)");
        T4.setSize(500, 500);
        T4.setVisible(true);

        T4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}