//Hafsa Salman
//22K-5161
//Task no. 01

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet(name = "Task_01_Register", urlPatterns = "/Register")
public class Task_01_Register extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException
    {
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        HttpSession session = req.getSession();
        session.setAttribute("registeredName", name);
        session.setAttribute("registeredEmail", email);
        session.setAttribute("registeredPassword", password);

        resp.sendRedirect("Signin.jsp");
    }
}