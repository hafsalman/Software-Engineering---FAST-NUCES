//Hafsa Salman
//22K-5161
//Task no. 01

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;


@WebServlet(name="Task_01_Signin", urlPatterns = "/Signin")
public class Task_01_Signin extends HttpServlet
{
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
        String email = req.getParameter("email");
        String password = req.getParameter("password");

        HttpSession session = req.getSession();
        String registeredEmail = (String) session.getAttribute("registeredEmail");
        String registeredPassword = (String) session.getAttribute("registeredPassword");

        if (registeredEmail != null && registeredEmail.equals(email) && registeredPassword.equals(password))
        {
            session.setAttribute("user", registeredEmail);
            resp.sendRedirect("welcome.jsp");
        }

        else
        {
            req.setAttribute("error", "Invalid email or password.");
            RequestDispatcher dispatcher = req.getRequestDispatcher("signin.jsp");
            dispatcher.forward(req, resp);
        }
    }
}