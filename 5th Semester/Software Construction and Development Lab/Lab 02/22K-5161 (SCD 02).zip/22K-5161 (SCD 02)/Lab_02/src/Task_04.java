//Hafsa Salman
//22K-5161
//Task no. 04

import java.util.Scanner;

public class Task_04
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task no. 04");
        System.out.println();

        Scanner s = new Scanner(System.in);

        Balance b = new Balance(1000);

        int amount;

        System.out.println("//Balance: 1000");
        System.out.println();

        System.out.print("Enter amount you want to withdraw: ");
        amount = s.nextInt();

        try
        {
            b.CheckBalance(amount);
        }

        catch (InsufficientBalanceException e)
        {
            System.out.println(e.getMessage());
        }
    }
}

class Balance
{
    int balance;

    public Balance (int balance)
    {
        this.balance = balance;
    }

    public void CheckBalance(int amount) throws InsufficientBalanceException
    {
        if (balance - amount < 100)
        {
            throw new InsufficientBalanceException("\nEXCEPTION: The balance should not go below $100!");
        }

        else
        {
            balance = balance - amount;

            System.out.println("Withdrawal Successful!");
            System.out.println("Current Balance: " + balance);
        }
    }
}

class InsufficientBalanceException extends Exception
{
    public InsufficientBalanceException(String Message)
    {
        super(Message);
    }
}