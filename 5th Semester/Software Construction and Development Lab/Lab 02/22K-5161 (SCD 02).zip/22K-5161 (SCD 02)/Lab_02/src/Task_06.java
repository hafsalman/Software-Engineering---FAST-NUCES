//Hafsa Salman
//22K-5161
//Task no. 06

import java.io.IOException;

public class Task_06
{
    public static void Exceptionnn() throws IOException
{
    throw new IOException("IO Exception!");
}

    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task 06");
        System.out.println();

        try
        {
            Exceptionnn();
        }

        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
    }
}