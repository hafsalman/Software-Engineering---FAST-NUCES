//Hafsa Salman
//22K-5161
//Task no. 05

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Task_05
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task no. 05");
        System.out.println();

        FileReader fr = null;

        try
        {
            File f = new File("ABC.txt");

            fr = new FileReader(f);

            int data;

            while ((data = fr.read()) != -1)
            {
                System.out.print((char) data);
            }
        }

        catch (FileNotFoundException e)
        {
            System.out.println("File not found " + e.getMessage());
        }

        catch (IOException e)
        {
            System.out.println("Error reading file  " + e.getMessage());
        }

        finally
        {
            if (fr != null)
            {
                try
                {
                    fr.close();
                    System.out.println("File closed successfully!");
                }

                catch (IOException e)
                {
                    System.out.println("Error closing file  " + e.getMessage());
                }
            }
        }
    }
}