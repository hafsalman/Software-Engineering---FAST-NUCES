//Hafsa Salman
//22K-5161
//Task no. 02

import java.util.Scanner;

public class Task_02
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task no. 02");
        System.out.println();

        Scanner s = new Scanner(System.in);

        String num_01;

        System.out.print("Enter number: ");
        num_01 = s.nextLine();

        int n_01 = 0;

        try
        {
            try
            {
                n_01 = Integer.parseInt(num_01);
            }

            catch (NumberFormatException e)
            {
                System.out.println();
                System.out.println(e);
                System.out.println("Can not convert!");
            }

            int num = n_01/0;
        }

        catch (ArithmeticException e)
        {
            System.out.println();
            System.out.println(e);
            System.out.println("Can not divide!");
        }
    }
}