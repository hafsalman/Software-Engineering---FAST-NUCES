//Hafsa Salman
//22K-5161
//Task no. 01

import java.util.InputMismatchException;
import java.util.Scanner;

public class Task_01
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task no. 01");
        System.out.println();

        Scanner s = new Scanner(System.in);

        int num;

        try
        {
            System.out.print("Enter Integer: ");
            num = s.nextInt();
        }

        catch (InputMismatchException e)
        {
            System.out.println();
            System.out.println(e);
            System.out.println("The input is invalid!");
        }
    }
}