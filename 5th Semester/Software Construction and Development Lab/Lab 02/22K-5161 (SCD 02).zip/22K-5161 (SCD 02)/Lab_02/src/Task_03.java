//Hafsa Salman
//Roll no. 22K-5161
//Task no. 03

import java.util.Scanner;

public class Task_03
{
    public static void main(String[] args)
    {

        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 02: Task no. 03");
        System.out.println();

        Scanner s  = new Scanner(System.in);

        int num_1, num_2;
        int num;

        System.out.print("Enter first number: ");
        num_1 = s.nextInt();

        System.out.print("Enter second number: ");
        num_2 = s.nextInt();

        try
        {
            num = num_1/num_2;
            System.out.println("Answer after division: " + num);
        }

        catch (ArithmeticException e)
        {
            System.out.println();
            System.out.println(e);
            System.out.println("Can not divide!");
        }

        int array[] = new int[5];

        try
        {
            array[0] = 0;
            array[1] = 0;
            array[2] = 0;
            array[3] = 0;
            array[4] = 0;
            array[5] = 0;
        }

        catch (ArrayIndexOutOfBoundsException e)
        {
            System.out.println();
            System.out.println(e);
            System.out.println("Array is of less index.");
        }
    }
}