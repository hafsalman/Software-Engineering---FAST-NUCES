package com.lab_12.lab_12;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab12ApplicationTests {

	@Test
	void contextLoads() {
	}

}
