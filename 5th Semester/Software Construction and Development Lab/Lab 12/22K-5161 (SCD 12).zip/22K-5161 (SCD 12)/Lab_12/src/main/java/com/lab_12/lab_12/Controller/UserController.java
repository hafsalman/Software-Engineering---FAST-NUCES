//Hafsa Salman
//22K-5161

package com.lab_12.lab_12.Controller;

import com.lab_12.lab_12.Model.Category;
import com.lab_12.lab_12.Model.Item;
import com.lab_12.lab_12.Model.User;
import com.lab_12.lab_12.Repository.CategoryRepository;
import com.lab_12.lab_12.Repository.ItemRepository;
import com.lab_12.lab_12.Repository.UserRepository;
import com.lab_12.lab_12.Service.UserService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping("/users")
public class UserController
{
    @Autowired
    private UserService userService;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private ItemRepository itemRepository;
    @Autowired
    private CategoryRepository categoryRepository;

    @GetMapping("/createAccount")
    public String createAccount(Model model)
    {
        model.addAttribute("user", new User());
        return "createAccount";
    }

    @PostMapping("/createAccount")
    public String createAccount(@ModelAttribute("user") User user, Model model)
    {
        if (user.getRole() == null || user.getRole().isEmpty())
        {
            user.setRole("user");
        }

        System.out.println("Role: " + user.getRole());

        userRepository.save(user);
        model.addAttribute("user", user);
        return "redirect:/users/login";
    }


    @GetMapping("/login")
    public String login()
    {
        return "login";
    }
    @PostMapping("/login")
    public String loginPage(Model model, @RequestParam String email, @RequestParam String password, HttpSession session, HttpServletResponse response)
    {
        User user=userService.validateUser(email, password);

        if(user!=null)
        {
            session.setAttribute("user", user);
            Cookie cookie = new Cookie("user_id", String.valueOf(user.getId()));
            response.addCookie(cookie);

            if (user.getRole().equals("super admin") || user.getRole().equals("admin"))
            {
                return "redirect:/users/SuperAndAdminDashboard";
            }

            return "redirect:/users/UserDashboard";
        }

        else
        {
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }
    }

    @GetMapping("/SuperAndAdminDashboard")
    public String SuperAndAdminDashboard(HttpSession session,Model model)
    {
        boolean superAdmin=false;
        User user=(User)session.getAttribute("user");
        if(user==null)
        {
            return "redirect:/users/login";
        }

        if(user.getRole().equals("super admin"))
        {
            superAdmin=true;
        }

        model.addAttribute("superAdmin", superAdmin);
        model.addAttribute("user", user);
        return "SuperAndAdminDashboard";
    }

    @GetMapping("/UserDashboard")
    public String UserDashboard(HttpSession session,Model model)
    {
        User user=(User)session.getAttribute("user");
        if(user==null)
        {
            return "redirect:/users/login";
        }

        model.addAttribute("user", user);

        return "UserDashboard";
    }

    @GetMapping("/manageUsers")
    public String manageUsers(HttpSession session,Model model)
    {
        User user=(User)session.getAttribute("user");
        List<User> users=userRepository.findByRole("user");

        if(user==null)
        {
            return "redirect:/users/login";
        }

        model.addAttribute("users", users);
        model.addAttribute("user", user);
        return "manageUsers";
    }

    @GetMapping("/manageAdmins")
    public String manageAdmins(HttpSession session,Model model)
    {
        User user=(User)session.getAttribute("user");
        List<User> admins=userRepository.findByRole("admin");

        if(user==null)
        {
            return "redirect:/users/login";
        }

        model.addAttribute("admins", admins);
        model.addAttribute("user", user);
        return "manageAdmins";
    }

    @GetMapping("/editUser/{id}")
    public String editUser(HttpSession session,Model model, @PathVariable ("id") int id)
    {
        boolean superAdmin=false;
        User editUser=userRepository.findById(id).orElseThrow(()->new IllegalArgumentException("Invalid User Id:" + id));
        User user=(User)session.getAttribute("user");

        if(user==null)
        {
            return "redirect:/users/login";
        }

        if(user.getRole().equals("super admin"))
        {
            superAdmin=true;
        }

        model.addAttribute("user", user);
        model.addAttribute("superAdmin", superAdmin);
        model.addAttribute("editUser", editUser);
        return "editUser";
    }

    @PostMapping("/editUser/{id}")
    public String editUser(@ModelAttribute("editUser") User user, HttpSession session, Model model,@PathVariable ("id") int id)
    {
        user.setId(id);
        userRepository.save(user);
        System.out.println(user.getRole());
        if(user.getRole().equals("admin"))
        {
            return "redirect:/users/manageAdmins";
        }

        else
        {
            return "redirect:/users/manageUsers";
        }
    }

    @GetMapping("/manageRestaurant")
    public String manageRestaurant(HttpSession session,Model model)
    {
        User user=(User)session.getAttribute("user");
        List<Item> items=itemRepository.findAll();
        List<Category> categories=categoryRepository.findAll();

        if(user==null)
        {
            return "redirect:/users/login";
        }
        model.addAttribute("user", user);
        model.addAttribute("items", items);
        model.addAttribute("categories", categories);

        return "manageRestaurant";
    }
}