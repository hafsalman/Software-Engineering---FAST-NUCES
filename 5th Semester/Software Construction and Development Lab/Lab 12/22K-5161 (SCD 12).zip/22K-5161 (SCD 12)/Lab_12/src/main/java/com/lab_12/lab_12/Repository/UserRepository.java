//Hafsa Salman
//22K-5161

package com.lab_12.lab_12.Repository;

import com.lab_12.lab_12.Model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Integer>
{
    Optional<User> findByEmail(String email);
    List<User> findByRole(String role);
}