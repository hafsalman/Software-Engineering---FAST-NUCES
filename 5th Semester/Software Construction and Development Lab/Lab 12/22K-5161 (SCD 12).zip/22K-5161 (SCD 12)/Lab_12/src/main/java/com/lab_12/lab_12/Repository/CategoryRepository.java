//Hafsa Salman
//22K-5161

package com.lab_12.lab_12.Repository;

import com.lab_12.lab_12.Model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Integer>
{
}