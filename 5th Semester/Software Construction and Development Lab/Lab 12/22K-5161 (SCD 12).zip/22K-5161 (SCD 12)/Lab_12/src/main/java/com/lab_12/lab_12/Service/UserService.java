//Hafsa Salman
//22K-5161

package com.lab_12.lab_12.Service;

import com.lab_12.lab_12.Model.User;
import com.lab_12.lab_12.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService
{
    @Autowired
    private UserRepository userRepository;

    public User validateUser(String email, String password)
    {
        Optional<User> user = userRepository.findByEmail(email);
        return user.filter(u -> u.getPassword().equals(password)).orElse(null);
    }
}