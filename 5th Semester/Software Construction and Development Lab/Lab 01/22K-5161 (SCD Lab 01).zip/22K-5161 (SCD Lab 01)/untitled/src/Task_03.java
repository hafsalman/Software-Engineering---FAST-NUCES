//22K-5161
//Task no. 03

public class Task_03
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 01: Task 03");
        System.out.println();

        NuclearBombs weapon = new NuclearBombs();

        weapon.WeaponDescription();
        weapon.HotWeaponsDescription();
        weapon.BombsDescription();
        weapon.NuclearBombsDescription();
    }
}

class Weapons
{
    public void WeaponDescription()
    {
        System.out.println("Following are the things that weapons do: ");
    }
}

class HotWeapons extends Weapons
{
    public void HotWeaponsDescription()
    {
        System.out.println("Hot weapons uses gunpowder, or explode.");
    }
}

class Bombs extends HotWeapons
{
    public void BombsDescription()
    {
        System.out.println("Bomb blow up.");
    }
}

class NuclearBombs extends Bombs
{
    public void NuclearBombsDescription()
    {
        System.out.println("Nuclear bombs blow up, and use nuclear fission and fusion.");
    }
}