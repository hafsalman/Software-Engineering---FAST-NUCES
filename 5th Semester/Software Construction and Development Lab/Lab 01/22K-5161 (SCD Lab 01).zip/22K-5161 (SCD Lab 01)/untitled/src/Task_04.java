//22K-5161
//Task no. 04

public class Task_04
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 01: Task 04");
        System.out.println();

        Person P = new Person();
        P.Draw();

        Artist A = new Artist();
        A.Draw();

        Gunman G = new Gunman();
        G.Draw();
    }
}

class Person
{
    private String name;
    private String occupation;

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setOccupation(String occupation)
    {
        this.occupation = occupation;
    }

    public String getOccupation()
    {
        return occupation;
    }

    public void Draw()
    {
        System.out.println("A person can draw in many ways.");
    }
}

class Artist extends Person
{
    @Override
    public void Draw()
    {
        System.out.println("An artist can draw with a paint brush.");
    }
}

class Gunman extends Person
{
    public void Draw()
    {
        System.out.println("A Gunman can draws a gun to shoot.");
    }
}