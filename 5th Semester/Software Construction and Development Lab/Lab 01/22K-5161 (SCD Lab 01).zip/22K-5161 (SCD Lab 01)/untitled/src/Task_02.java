//22K-5161
//Task no. 02

import java.util.Scanner;

public class Task_02
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 01: Task 02");
        System.out.println();

        Scanner s = new Scanner(System.in);

        ScienceTeacher ST = new ScienceTeacher();

        System.out.print("Enter Name: ");
        ST.setName(s.nextLine());

        System.out.print("Enter Age: ");
        ST.setAge(s.nextInt());

        s.nextLine();

        System.out.print("Enter Institute: ");
        ST.setInstitute(s.nextLine());

        System.out.print("Enter ID: ");
        ST.setId(s.nextInt());

        s.nextLine();

        System.out.print("Enter Email: ");
        ST.setEmail(s.nextLine());

        System.out.print("Enter Number: ");
        ST.setNum(s.nextLine());

        System.out.print("Enter Specialization: ");
        ST.specialization = s.nextLine();

        System.out.print("Enter Years of Experience: ");
        ST.years = s.nextInt();

        s.nextLine();

        System.out.print("Enter Research Interest: ");
        ST.interest = s.nextLine();

        System.out.println();

        ST.Print();
    }
}

class Teacher
{
    private String name;
    private int age;
    private String institute;

    public Teacher()
    {
        this.name = name;
        this.age = age;
        this.institute = institute;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setAge(int age)
    {
        this.age = age;
    }

    public int getAge()
    {
        return age;
    }

    public void setInstitute(String institute)
    {
        this.institute = institute;
    }

    public String getInstitute()
    {
        return institute;
    }

    public void Print()
    {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Institute: " + institute);
    }
}

class ScienceTeacher extends Teacher
{
    private int id;
    private String email;
    private String num;

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return email;
    }

    public void setNum(String num)
    {
        this.num = num;
    }

    public String getNum()
    {
        return num;
    }

    String specialization;
    int years;
    String interest;

    @Override
    public void Print()
    {
        System.out.println("SCIENCE TEACHER: ");
        super.Print();
        System.out.println("ID: " + id);
        System.out.println("Email: " + email);
        System.out.println("Number: " + num);
        System.out.println("Specialization: " + specialization);
        System.out.println("Years of Experience: " + years);
        System.out.println("Research Interest: " + interest);
    }
}

class MathsTeacher extends Teacher
{
    private int id;
    private String email;
    private String num;

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return email;
    }

    public void setNum(String num)
    {
        this.num = num;
    }

    public String getNum()
    {
        return num;
    }

    String specialization;
    int years;
    String interest;
}

class HumanitiesTeacher extends Teacher
{
    private int id;
    private String email;
    private String num;

    public void setId(int id)
    {
        this.id = id;
    }

    public int getId()
    {
        return id;
    }

    public void setEmail(String email)
    {
        this.email = email;
    }

    public String getEmail()
    {
        return email;
    }

    public void setNum(String num)
    {
        this.num = num;
    }

    public String getNum()
    {
        return num;
    }

    String specialization;
    int years;
    String interest;
}