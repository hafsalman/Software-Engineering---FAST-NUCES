//22K-5161
//Task no. 01

import java.util.Scanner;

public class Task_01
{
    public static void main(String[] args)
    {
        System.out.println("Name: Hafsa Salman");
        System.out.println("Roll no. 22K-5161");
        System.out.println("SCD Lab 01: Task 01");
        System.out.println();

        Scanner s = new Scanner(System.in);

        student student = new student();

        System.out.print("Enter First Name: ");
        student.setFirst(s.nextLine());

        System.out.print("Enter Last Name: ");
        student.setLast(s.nextLine());

        System.out.print("Enter Roll no. ");
        student.setRoll(s.nextLine());

        System.out.print("Enter Major: ");
        student.setMajor(s.nextLine());

        System.out.print("Enter the sum of scores you obtained in 3 courses: ");
        student.setComp_credits(s.nextFloat());

        System.out.print("Enter total credit hours: ");
        student.setTotal(s.nextInt());

        System.out.println();

        student.calculation(student.getComp_credits(), student.getTotal());
        student.print();
    }
}

class student
{
    private String first;
    private String last;
    private String roll;
    private String Major;
    private float comp_credits;
    private int total;
    private float GPA;

    public String getFirst()
    {
        return first;
    }

    public void setFirst(String first)
    {
        this.first = first;
    }

    public String getLast()
    {
        return last;
    }

    public void setLast(String last)
    {
        this.last = last;
    }

    public String getRoll()
    {
        return roll;
    }

    public void setRoll(String roll)
    {
        this.roll = roll;
    }

    public String getMajor()
    {
        return Major;
    }

    public void setMajor(String major)
    {
        Major = major;
    }

    public float getComp_credits()
    {
        return comp_credits;
    }

    public void setComp_credits(float comp_credits)
    {
        this.comp_credits = comp_credits;
    }

    public int getTotal()
    {
        return total;
    }

    public void setTotal(int total)
    {
        this.total = total;
    }

    public float getGPA()
    {
        return GPA;
    }

    public void setGPA(float GPA)
    {
        this.GPA = GPA;
    }

    public void calculation(float comp_credits, int total)
    {
        GPA = (comp_credits * 3)/total;
    }

    public void print()
    {
        System.out.println("First Name: " + first);
        System.out.println("Last Name: " + last);
        System.out.println("Roll no. " + roll);
        System.out.println("GPA: " + GPA);
    }
}