package com.example.servlet;
import com.example.db.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@WebServlet(name = "ItemServlet", urlPatterns = "/ItemServlet")
public class ItemServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DBConnection.getConnection()) {
            // Fetch items and categories from the database
            Locale.setDefault(Locale.US);
            List<Item> items = getItems(conn);
            List<Category> categories = getCategories(conn);

            // Set the items and categories as request attributes
            request.setAttribute("items", items);
            request.setAttribute("categories", categories);

            // Forward the request to the manageItems.jsp page
            request.getRequestDispatcher("/manageItems.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle error
        }
    }

    private List<Item> getItems(Connection conn) throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "SELECT i.itemID, i.item_name, i.item_price, c.category_name FROM ITEMS i " +
                "JOIN CATEGORIES c ON i.categoryID = c.categoryID";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            List<Item> items = new ArrayList<>();
            while (rs.next()) {
                int itemId = rs.getInt("itemID");
                String itemName = rs.getString("item_name");
                double itemPrice = rs.getDouble("item_price");
                String categoryName = rs.getString("category_name");
                items.add(new Item(itemId, itemName, itemPrice, categoryName));
            }
            return items;
        }
    }

    private List<Category> getCategories(Connection conn) throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "SELECT categoryID, category_name FROM CATEGORIES";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            List<Category> categories = new ArrayList<>();
            while (rs.next()) {
                int categoryId = rs.getInt("categoryID");
                String categoryName = rs.getString("category_name");
                categories.add(new Category(categoryId, categoryName));
            }
            return categories;
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String itemName = request.getParameter("itemName");
        double itemPrice = Double.parseDouble(request.getParameter("itemPrice"));
        int categoryId = Integer.parseInt(request.getParameter("categoryId"));
        int itemId = 0;

        try (Connection conn = DBConnection.getConnection()) {
            Locale.setDefault(Locale.US);
            switch (action) {
                case "add":
                    addItem(conn, itemName, itemPrice, categoryId);
                    break;
                case "edit":
                    itemId = Integer.parseInt(request.getParameter("itemId"));
                    updateItem(conn, itemId, itemName, itemPrice, categoryId);
                    break;
                case "delete":
                    itemId = Integer.parseInt(request.getParameter("itemId"));
                    deleteItem(conn, itemId);
                    break;
            }
            response.sendRedirect("ItemServlet");
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            // Handle error
        }
    }

    private void addItem(Connection conn, String itemName, double itemPrice, int categoryId) throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "INSERT INTO ITEMS (itemID, item_name, item_price, categoryID) VALUES (ITEM_SEQ.NEXTVAL, ?, ?, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, itemName);
            ps.setDouble(2, itemPrice);
            ps.setInt(3, categoryId);
            ps.executeUpdate();
        }
    }

    private void updateItem(Connection conn, int itemId, String itemName, double itemPrice, int categoryId) throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "UPDATE ITEMS SET item_name = ?, item_price = ?, categoryID = ? WHERE itemID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, itemName);
            ps.setDouble(2, itemPrice);
            ps.setInt(3, categoryId);
            ps.setInt(4, itemId);
            ps.executeUpdate();
        }
    }

    private void deleteItem(Connection conn, int itemId) throws SQLException {
        Locale.setDefault(Locale.US);
        String sql = "DELETE FROM ITEMS WHERE itemID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, itemId);
            ps.executeUpdate();
        }
    }
}
class Item {
    private int itemId;
    private String itemName;
    private double itemPrice;
    private String categoryName;

    public Item(int itemId, String itemName, double itemPrice, String categoryName) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.categoryName = categoryName;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
}