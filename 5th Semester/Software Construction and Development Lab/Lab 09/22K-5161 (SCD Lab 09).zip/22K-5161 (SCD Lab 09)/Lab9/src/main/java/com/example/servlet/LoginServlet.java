package com.example.servlet;

import com.example.db.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.*;
import java.util.Locale;

@WebServlet(name = "LoginServlet", urlPatterns = "/LoginServlet")

//public class LoginServlet extends HttpServlet {
//
//    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//        String email = request.getParameter("email");
//        String password = request.getParameter("password");
//
//        try (Connection conn = DBConnection.getConnection()) {
//            Locale.setDefault(Locale.US);
//            String query = "SELECT userID, USER_ROLE FROM USERS WHERE email = ? AND password = ?";
//            try (PreparedStatement ps = conn.prepareStatement(query)) {
//                ps.setString(1, email);
//                ps.setString(2, password);
//                ResultSet rs = ps.executeQuery();
//
//                if (rs.next()) {
//                    String role = rs.getString("USER_ROLE");
//                    HttpSession session = request.getSession();
//                    session.setAttribute("userRole", role);
//                    session.setAttribute("userID", rs.getString("userID"));
//
//                    if ("super_admin".equals(role) || "admin".equals(role)) {
//                        response.sendRedirect("manageUsers.jsp");
//                    } else {
//                        response.sendRedirect("catalog.jsp");
//                    }
//                } else {
//                    request.setAttribute("error", "Invalid credentials");
//                    request.getRequestDispatcher("login.jsp").forward(request, response);
//                }
//            }
//        } catch (SQLException | ClassNotFoundException e) {
//            e.printStackTrace();
//            request.setAttribute("error", "Database connection error. Please try again later.");
//            request.getRequestDispatcher("login.jsp").forward(request, response);
//        }
//    }
//}


public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT userID, USER_ROLE FROM USERS WHERE email = ? AND password = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, email);
                ps.setString(2, password);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    HttpSession session = request.getSession();
                    session.setAttribute("userID", rs.getInt("userID"));
                    session.setAttribute("role", rs.getString("USER_ROLE"));
                    response.sendRedirect("dashboard.jsp");
                } else {
                    response.sendRedirect("login.jsp?error=Invalid credentials");
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
