package com.example.servlet;

import com.example.db.DBConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.Locale;

@WebServlet(name = "RegisterServlet", urlPatterns = "/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userID = request.getParameter("userID");
        String email = request.getParameter("email");
        String fullName = request.getParameter("fullName");
        String password = request.getParameter("password");
        String dob = request.getParameter("dob");

        try (Connection conn = DBConnection.getConnection()) {
            if (isUnique(conn, userID, email)) {
                Locale.setDefault(Locale.US);
                String insertUserSQL = "INSERT INTO USERS (userID, email, full_name, password, DOB, USER_ROLE) VALUES (?, ?, ?, ?, ?, ?)";
//                String insertUserSQL = "INSERT INTO USERS (userID, email, full_name, password, DOB) VALUES (?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(insertUserSQL)) {
                    ps.setString(1, userID);
                    ps.setString(2, email);
                    ps.setString(3, fullName);
                    ps.setString(4, password);
                    ps.setDate(5, Date.valueOf(dob));
                    ps.setString(6, "user");
                    ps.executeUpdate();
                    response.sendRedirect("login.jsp");
                }
            } else {
                request.setAttribute("error", "UserID or email already exists.");
                request.getRequestDispatcher("register.jsp").forward(request, response);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private boolean isUnique(Connection conn, String userID, String email) throws SQLException {
        Locale.setDefault(Locale.US);
        String query = "SELECT COUNT(*) FROM USERS WHERE userID = ? OR email = ?";
        try (PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, userID);
            ps.setString(2, email);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) == 0;
        }
    }
}
