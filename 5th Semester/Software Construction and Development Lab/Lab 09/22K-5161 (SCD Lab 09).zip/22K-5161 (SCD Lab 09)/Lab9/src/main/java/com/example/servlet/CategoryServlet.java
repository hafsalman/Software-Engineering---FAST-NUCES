package com.example.servlet;

import com.example.db.DBConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@WebServlet(name = "CategoryServlet", urlPatterns = "/CategoryServlet")
public class CategoryServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String categoryName = request.getParameter("categoryName");

        try (Connection conn = DBConnection.getConnection()) {
            Locale.setDefault(Locale.US);
            int categoryId = 0;
            switch (action) {
                case "add":
                    addCategory(conn, categoryName);
                    break;
                case "edit":
                    categoryId = Integer.parseInt(request.getParameter("categoryId"));
                    updateCategory(conn, categoryId, categoryName);
                    break;
                case "delete":
                    categoryId = Integer.parseInt(request.getParameter("categoryId"));
                    deleteCategory(conn, categoryId);
                    break;
            }
            response.sendRedirect("manageCategories.jsp"); // Redirect after action
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Fetch all categories (to be used in doGet)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try (Connection conn = DBConnection.getConnection()) {
            Locale.setDefault(Locale.US);
            List<Category> categories = getAllCategories(conn);
            request.setAttribute("categories", categories); // Set categories as a request attribute
            RequestDispatcher dispatcher = request.getRequestDispatcher("manageCategories.jsp"); // Forward to JSP
            dispatcher.forward(request, response);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private List<Category> getAllCategories(Connection conn) throws SQLException {
        Locale.setDefault(Locale.US); // Set locale before query
        String sql = "SELECT categoryID, category_name FROM CATEGORIES";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            List<Category> categories = new ArrayList<>();
            while (rs.next()) {
                int categoryId = rs.getInt("categoryID");
                String categoryName = rs.getString("category_name");
                categories.add(new Category(categoryId, categoryName)); // Assuming Category class has appropriate constructor
            }
            return categories;
        }
    }

    private void addCategory(Connection conn, String categoryName) throws SQLException {
        Locale.setDefault(Locale.US); // Set locale before query
        String sql = "INSERT INTO CATEGORIES (categoryID, category_name) VALUES (CATEGORY_SEQ.NEXTVAL, ?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, categoryName);
            ps.executeUpdate();
        }
    }

    private void updateCategory(Connection conn, int categoryId, String categoryName) throws SQLException {
        Locale.setDefault(Locale.US); // Set locale before query
        String sql = "UPDATE CATEGORIES SET category_name = ? WHERE categoryID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, categoryName);
            ps.setInt(2, categoryId);
            ps.executeUpdate();
        }
    }

    private void deleteCategory(Connection conn, int categoryId) throws SQLException {
        Locale.setDefault(Locale.US); // Set locale before query
        String sql = "DELETE FROM CATEGORIES WHERE categoryID = ?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, categoryId);
            ps.executeUpdate();
        }
    }
}

class Category {
    private int categoryId;
    private String categoryName;

    // Constructor
    public Category(int categoryId, String categoryName) {
        this.categoryId = categoryId;
        this.categoryName = categoryName;
    }

    // Getter for categoryId
    public int getCategoryId() {
        return categoryId;
    }

    // Setter for categoryId
    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    // Getter for categoryName
    public String getCategoryName() {
        return categoryName;
    }

    // Setter for categoryName
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    @Override
    public String toString() {
        return "Category{" +
                "categoryId=" + categoryId +
                ", categoryName='" + categoryName + '\'' +
                '}';
    }
}
