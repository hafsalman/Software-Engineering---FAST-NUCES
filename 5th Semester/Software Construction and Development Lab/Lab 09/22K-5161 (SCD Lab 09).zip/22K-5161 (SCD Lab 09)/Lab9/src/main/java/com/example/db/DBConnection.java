package com.example.db;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Locale;
import java.util.Properties;

public class DBConnection {
    private static Connection connection = null;

    public static Connection getConnection() throws ClassNotFoundException {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        Locale.setDefault(Locale.US);
        if (connection != null) {
            System.out.println("Database Connected!");
            return connection;}

        try (InputStream input = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
            Properties prop = new Properties();
            prop.load(input);

            String url = prop.getProperty("db.url");
            String user = prop.getProperty("db.username");
            String password = prop.getProperty("db.password");

            connection = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            System.out.println("Failed To Connect Database");
            e.printStackTrace();
        }

        return connection;
    }

    public static void main(String[] args) throws ClassNotFoundException {
        Connection testConnection = DBConnection.getConnection();
        if (testConnection != null) {
            System.out.println("Connection successful!");
        } else {
            System.out.println("Connection failed.");
        }
    }
}
