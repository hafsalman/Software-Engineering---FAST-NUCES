//Hafsa Salman
//22K-5161
//Task no. 06

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class Task_06 extends JFrame
{
    private JPanel Login;
    private JLabel Username;
    private JTextField UsernameTxt;
    private JPasswordField PasswordTxt;
    private JLabel Password;
    private JButton btn01;
    private JLabel Logo;

    public Task_06() {
        btn01.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                char[] pass = PasswordTxt.getPassword();
                String password = new String(pass);


                if (Objects.equals(password, "12345") && Objects.equals(UsernameTxt.getText(), "Hafsa"))
                {
                    Home home = new Home();
                    home.Print();
                    dispose();
                }

                else
                {
                    JOptionPane.showMessageDialog(btn01, "Invalid Username or Password!");
                }
            }
        });
    }

    public static void main(String[] args)
    {
        Task_06 T6 = new Task_06();

        T6.setContentPane(T6.Login);
        T6.setTitle("Flex Students (22K-5161)");
        T6.setSize(600, 700);
        T6.setVisible(true);

        T6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
