//Hafsa Salman
//22K-5161
//Task no. 05

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_05 extends JFrame
{
    private JPanel Task_05;
    private JLabel Name;
    private JTextField NameTxt;
    private JLabel Food;
    private JComboBox FoodTxt;
    private JLabel Quantity;
    private JSpinner QuantityTxt;
    private JButton btn;

    public Task_05() {
        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(btn, NameTxt.getText() + ", you have ordered " + QuantityTxt.getValue() + " " + FoodTxt.getSelectedItem() + ".");
            }
        });
    }

    public static void main(String[] args)
    {
        Task_05 T5 = new Task_05();

        T5.setContentPane(T5.Task_05);
        T5.setTitle("Order Form (22K-5161)");
        T5.setSize(400, 300);
        T5.setVisible(true);

        T5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
