//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_02 extends JFrame
{
    private JPanel Task_02;
    private JLabel SearchBar;
    private JTextField SearchTxt;
    private JButton btn;
    private JTextArea Area1;

    public Task_02 ()
    {
        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed (ActionEvent e)
            {
                JOptionPane.showMessageDialog(btn, "Search Term: " + SearchTxt.getText() + "\nResult: " + "\n1. JAVA Programming \n2.C Programming \n3. C++ Programming");
            }
        });
    }

    public static void main(String[] args)
    {
        Task_02 T2 = new Task_02();

        T2.setContentPane(T2.Task_02);
        T2.setTitle("Library Book Form (22K-5161)");
        T2.setSize(400, 300);
        T2.setVisible(true);

        T2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
