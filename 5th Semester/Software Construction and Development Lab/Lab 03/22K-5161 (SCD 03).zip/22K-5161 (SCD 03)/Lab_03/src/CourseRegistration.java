//Hafsa Salman
//22K-5161
//Task no. 06

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CourseRegistration extends JFrame
{
    private JButton profileButton;
    private JButton homeButton;
    private JButton courseRegistrationButton;
    private JButton attendanceButton;
    private JButton marksButton;
    private JButton transcriptButton;
    private JButton feeChallanButton;
    private JButton courseFeedbackButton;
    private JButton retakeExamRequestButton;
    private JButton gradeChangeRequestButton;
    private JTextArea courseRegistrationPeriodIsTextArea;
    private JPanel CourseR;

    public CourseRegistration() {
        homeButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Home home = new Home();
                home.Print();
                dispose();
            }
        });


        courseRegistrationButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CourseRegistration courseRegistration = new CourseRegistration();
                courseRegistration.Print();
                dispose();
            }
        });


        attendanceButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Attendance attendance = new Attendance();
                attendance.Print();
                dispose();
            }
        });


        marksButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Marks marks = new Marks();
                marks.Print();
                dispose();
            }
        });


        transcriptButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Transcript transcript = new Transcript();
                transcript.Print();
                dispose();
            }
        });


        feeChallanButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                FeeChallan feeChallan = new FeeChallan();
                feeChallan.Print();
                dispose();
            }
        });


        courseFeedbackButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CourseFeedback courseFeedback = new CourseFeedback();
                courseFeedback.Print();
                dispose();
            }
        });


        retakeExamRequestButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                RetakeExamRequest retakeExamRequest = new RetakeExamRequest();
                retakeExamRequest.Print();
                dispose();
            }
        });


        gradeChangeRequestButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                GradeChangeRequest gradeChangeRequest = new GradeChangeRequest();
                gradeChangeRequest.Print();
                dispose();
            }
        });
    }

    public void Print()
    {
        CourseRegistration T6 = new CourseRegistration();
        T6.setContentPane(T6.CourseR);
        T6.setTitle("CourseRegistration (22K-5161)");
        T6.setSize(600, 700);
        T6.setVisible(true);
        T6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args)
    {
        CourseRegistration T6 = new CourseRegistration();

        T6.setContentPane(T6.CourseR);
        T6.setTitle("Course Registration (22K-5161)");
        T6.setSize(600, 700);
        T6.setVisible(true);

        T6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
