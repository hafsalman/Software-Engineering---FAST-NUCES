//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_03 extends JFrame
{
    private JPanel Task_03;
    private JLabel Name;
    private JTextField Pname;
    private JLabel CF;
    private JTextArea Comments;
    private JComboBox Rate;
    private JLabel RateEvent;
    private JButton btn;

    public Task_03() {
        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                JOptionPane.showMessageDialog(btn, "Thank You, " + Pname.getText() + "!" + "\nRate: " + Rate.getSelectedItem().toString() + "\nFeedback: " + Comments.getText());
            }
        });
    }

    public static void main(String[] args)
    {
        Task_03 T3 = new Task_03();

        T3.setContentPane(T3.Task_03);
        T3.setTitle("Feedback Form (22K-5161)");
        T3.setSize(400, 300);
        T3.setVisible(true);

        T3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}