//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Task_01 extends JFrame
{
    private JPanel Task_01;
    private JLabel Name;
    private JTextField NameTxt;
    private JLabel Grade;
    private JComboBox GradeCombo;
    private JLabel Activities;
    private JCheckBox Box_01;
    private JCheckBox Box_02;
    private JCheckBox Box_03;
    private JButton btn;

    String str;

    public Task_01()
    {
        btn.addActionListener (new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                if (Box_01.isSelected())
                {
                    str = Box_01.getText();
                }

                if (Box_02.isSelected())
                {
                    str = Box_02.getText();
                }

                if (Box_03.isSelected())
                {
                    str = Box_03.getText();
                }

                JOptionPane.showMessageDialog(btn, "Student Name: " + NameTxt.getText() + "\nGrade: " + GradeCombo.getSelectedItem() + "\nActivities: " + str);
            }
        });
    }

    public static void main(String[] args)
    {
        Task_01 T = new Task_01();

        T.setContentPane(T.Task_01);
        T.setTitle("Registration Form (22K-5161)");
        T.setSize(400, 300);
        T.setVisible(true);

        T.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
