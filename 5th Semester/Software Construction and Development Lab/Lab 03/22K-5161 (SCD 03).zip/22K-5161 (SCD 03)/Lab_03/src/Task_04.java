//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Objects;

public class Task_04 extends JFrame
{
    private JPanel Task_04;
    private JLabel Username;
    private JTextField UsernameTxt;
    private JLabel Password;
    private JButton btn;
    private JPasswordField PasswordTxt;

    public Task_04()
    {
        btn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                char[] pass = PasswordTxt.getPassword();
                String password = new String(pass);


                if (Objects.equals(password, "12345") && Objects.equals(UsernameTxt.getText(), "Hafsa"))
                {
                    JOptionPane.showMessageDialog(btn, "Login Successful!");
                }

                else
                {
                    JOptionPane.showMessageDialog(btn, "Wrong Username or Password!");
                }
            }
        });
    }

    public static void main(String[] args)
    {
        Task_04 T4 = new Task_04();

        T4.setContentPane(T4.Task_04);
        T4.setTitle("Login System (22K-5161)");
        T4.setSize(400, 300);
        T4.setVisible(true);

        T4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}