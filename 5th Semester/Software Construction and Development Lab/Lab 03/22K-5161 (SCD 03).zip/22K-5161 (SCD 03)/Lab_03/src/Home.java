//Hafsa Salman
//22K-5161
//Task no. 06

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Home extends JFrame
{
    private JButton Home;
    private JPanel HomePage;
    private JButton CR;
    private JButton Attend;
    private JButton Marks;
    private JButton Transcript;
    private JButton FC;
    private JButton CourseFeed;
    private JButton RER;
    private JButton CW;
    private JButton GCR;
    private JButton profileButton;
    private JTextArea universityInformationTextArea;
    private JTextArea academicCalendarTextArea;
    private JTextArea contactInformationTextArea;
    private JTextArea familyInformationTextArea;

    public Home()
    {
        Home.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Home home = new Home();
                home.Print();
                dispose();
            }
        });

        CR.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CourseRegistration cr = new CourseRegistration();
                cr.Print();
                dispose();
            }
        });

        Attend.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Attendance a  = new Attendance();
                a.Print();
                dispose();
            }
        });


        Marks.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Marks m = new Marks();
                m.Print();
                dispose();
            }
        });

        Transcript.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                Transcript t = new Transcript();
                t.Print();
                dispose();
            }
        });


        FC.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e)
            {
                FeeChallan fc = new FeeChallan();
                fc.Print();
                dispose();
            }
        });

        CourseFeed.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                CourseFeedback cf = new CourseFeedback();
                cf.Print();
                dispose();
            }
        });

        RER.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                RetakeExamRequest rer = new RetakeExamRequest();
                rer.Print();
                dispose();
            }
        });


        GCR.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                GradeChangeRequest gcr = new GradeChangeRequest();
                gcr.Print();
                dispose();
            }
        });
    }

    public void Print()
    {
        Home T6 = new Home();
        T6.setContentPane(T6.HomePage);
        T6.setTitle("HomePage (22K-5161)");
        T6.setSize(600, 700);
        T6.setVisible(true);
        T6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args)
    {
        Home T6 = new Home();

        T6.setContentPane(T6.HomePage);
        T6.setTitle("Home Page (22K-5161)");
        T6.setSize(600, 700);
        T6.setVisible(true);

        T6.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}
