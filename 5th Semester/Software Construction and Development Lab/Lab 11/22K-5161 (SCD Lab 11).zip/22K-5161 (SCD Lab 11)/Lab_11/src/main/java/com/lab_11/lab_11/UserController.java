//Hafsa Salman
//22K-5161
//Task no. 02

package com.lab_11.lab_11;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashSet;
import java.util.Set;

@Controller
public class UserController
{
    private final Set<String> registeredUsers = new HashSet<>(Set.of("Hafsa", "12345"));

    @GetMapping("/menu")
    public String showMenu()
    {
        return "menu";
    }

    @GetMapping("/loginPage")
    public String showLoginPage()
    {
        return "login";
    }

    @GetMapping("/registerPage")
    public String showRegisterPage()
    {
        return "Register";
    }

    @PostMapping("/register")
    @ResponseBody
    public String registerUser(@RequestParam String username, @RequestParam String password)
    {
        if (registeredUsers.contains(username))
        {
            return "Username is already in use, please choose diffrent one.";
        }

        else
        {
            registeredUsers.add(username);
            return "Registration successful for user: " + username;
        }
    }

    @PostMapping("/login")
    @ResponseBody
    public String loginUser(@RequestParam String username, @RequestParam String password) {
        if (registeredUsers.contains(username))
        {
            return "Login successful for user: " + username;
        }

        else
        {
            return "Login failed: Username not found or incorrect password.";
        }
    }
}