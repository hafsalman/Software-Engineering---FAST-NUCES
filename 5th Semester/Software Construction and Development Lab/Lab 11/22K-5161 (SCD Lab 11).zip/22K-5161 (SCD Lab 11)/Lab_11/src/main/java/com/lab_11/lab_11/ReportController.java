//Hafsa Salman
//22K-5161
//Task no. 04

package com.lab_11.lab_11;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ReportController
{
    @GetMapping("/report/{year}/{month}")
    public String getReport(
            @PathVariable int year,
            @PathVariable String month,
            @RequestParam(name = "type", defaultValue = "summary") String type)
    {
        String reportType = type.equalsIgnoreCase("detailed") ? "a detailed" : "a summary";
        return "Displaying " + reportType + " report for " + month + " " + year + ".";
    }
}