//Hafsa Salman
//22K-5161
//Task 11

package com.lab_11.lab_11;


import org.springframework.stereotype.Service;
import java.time.LocalTime;
import java.util.Map;

@Service
public class GreetingService
{
    private static final Map<String, String> GREETINGS_ENGLISH = Map.of(
            "morning", "Good morning",
            "afternoon", "Good afternoon",
            "evening", "Good evening"
    );

    private static final Map<String, String> GREETINGS_FRENCH = Map.of(
            "morning", "Bonjour",
            "afternoon", "Bon après-midi",
            "evening", "Bonsoir"
    );

    private static final Map<String, String> GREETINGS_SPANISH = Map.of(
            "morning", "Buenos días",
            "afternoon", "Buenas tardes",
            "evening", "Buenas noches"
    );

    public String getGreeting(String language)
    {
        Map<String, String> greetingsMap = switch (language.toLowerCase())
        {
            case "french" -> GREETINGS_FRENCH;
            case "spanish" -> GREETINGS_SPANISH;
            default -> GREETINGS_ENGLISH;
        };

        String timeOfDay = getTimeOfDay();
        return greetingsMap.getOrDefault(timeOfDay, "Hello");
    }

    private String getTimeOfDay()
    {
        int hour = LocalTime.now().getHour();
        if (hour >= 5 && hour < 12)
        {
            return "morning";
        }

        else if (hour >= 12 && hour < 17)
        {
            return "afternoon";
        }

        else
        {
            return "evening";
        }
    }
}