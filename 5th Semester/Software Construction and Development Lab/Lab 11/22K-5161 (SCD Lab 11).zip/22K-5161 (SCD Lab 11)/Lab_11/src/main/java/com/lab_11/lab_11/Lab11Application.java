//Hafsa Salman
//22K-5161
//SCD Lab 11

package com.lab_11.lab_11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab11Application
{
	public static void main(String[] args)
	{
		SpringApplication.run(Lab11Application.class, args);
	}
}