//Hafsa Salman
//22K-5161
//Task no. 05

package com.lab_11.lab_11;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ProductController
{
    private List<Product> getProducts()
    {
        List<Product> products = new ArrayList<>();

        products.add(new Product("Chocolate", "Food"));
        products.add(new Product("Pizza", "Food"));
        products.add(new Product("Sandwich", "Food"));
        products.add(new Product("Pasta", "Food"));
        products.add(new Product("Stapler", "Office Supplies"));
        products.add(new Product("Highlighter", "Office Supplies"));
        products.add(new Product("Calculator", "Office Supplies"));
        products.add(new Product("Soda", "Drinks"));
        products.add(new Product("Milkshake", "Drinks"));
        products.add(new Product("Smoothie", "Drinks"));

        return products;
    }

    @GetMapping("/products")
    public String showProducts(@RequestParam(name = "category", required = false) String category, Model model)
    {
        List<Product> products = getProducts();

        List<Product> filteredProducts = new ArrayList<>();

        if (category != null && !category.isEmpty())
        {
            for (Product product : products)
            {
                if (product.getCategory().equalsIgnoreCase(category))
                {
                    filteredProducts.add(product);
                }
            }
        }

        else
        {
            filteredProducts = products;
        }

        model.addAttribute("products", filteredProducts);
        model.addAttribute("selectedCategory", category);

        return "products";
    }
}