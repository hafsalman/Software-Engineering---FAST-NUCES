//Hafsa Salman
//22K-5161
//Task no. 03

package com.lab_11.lab_11;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@Controller
public class ItemController
{
    private final List<Item> itemList = new ArrayList<>();

    @GetMapping("/itemMenu")
    public String itemMenu()
    {
        return "itemMenu";
    }

    @GetMapping("/addItemForm")
    public String showAddItemForm()
    {
        return "addItemForm";
    }

    @PostMapping("/addItemForm")
    public String addItem(@RequestParam int id, @RequestParam String name, @RequestParam int quantity, Model model) {
        itemList.add(new Item(id, name, quantity));
        model.addAttribute("message", "Item added successfully.");
        return "itemMenu";
    }

    @GetMapping("/getItemForm")
    public String showGetItemForm()
    {
        return "getItemForm";
    }

    @PostMapping("/getItem")
    public String getItemById(@RequestParam int id, Model model)
    {
        Item foundItem = null;
        for (Item item : itemList)
        {
            if (item.getId() == id)
            {
                foundItem = item;
                break;
            }
        }

        if (foundItem != null)
        {
            model.addAttribute("item", foundItem);
        }

        else
        {
            model.addAttribute("message", "Item not found.");
        }
        return "getItemForm";
    }

    @GetMapping("/updateItemForm")
    public String showUpdateItemForm()
    {
        return "updateItemForm";
    }

    @PostMapping("/updateItem")
    public String updateItem(@RequestParam int id, @RequestParam String name, @RequestParam int quantity, Model model)
    {
        boolean itemUpdated = false;

        for (Item item : itemList)
        {
            if (item.getId() == id)
            {
                item.setName(name);
                item.setQuantity(quantity);
                itemUpdated = true;
                break;
            }
        }

        if (itemUpdated)
        {
            model.addAttribute("message", "Item updated successfully.");
        }

        else
        {
            model.addAttribute("message", "Item not found.");
        }

        return "updateItemForm";
    }

    @GetMapping("/deleteItemForm")
    public String showDeleteItemForm()
    {
        return "deleteItemForm";
    }

    @PostMapping("/deleteItem")
    public String deleteItem(@RequestParam int id, Model model)
    {
        boolean itemFoundAndRemoved = false;

        for (Item item : itemList)
        {
            if (item.getId() == id)
            {
                itemList.remove(item);
                itemFoundAndRemoved = true;

                break;
            }
        }

        model.addAttribute("message", itemFoundAndRemoved ? "Item deleted successfully." : "Item not found.");
        return "deleteItemForm";
    }

    @GetMapping("/viewAllItems")
    public String viewAllItems(Model model)
    {
        model.addAttribute("items", itemList);

        return "viewAllItems";
    }
}