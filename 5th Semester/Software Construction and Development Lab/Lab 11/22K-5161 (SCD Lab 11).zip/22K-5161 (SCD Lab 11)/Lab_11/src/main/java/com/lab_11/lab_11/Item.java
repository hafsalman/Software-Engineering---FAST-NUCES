//Hafsa Salman
//22K-5161
//Task no. 03

package com.lab_11.lab_11;

public class Item
{
    private int Id;
    private String name;
    private int quantity;

    public Item (int Id, String name, int quantity)
    {
        this.Id = Id;
        this.name = name;
        this.quantity = this.quantity;
    }

    public int getId()
    {
        return Id;
    }

    public void setId(int Id)
    {
        this.Id = Id;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}