//Hafsa Salman
//22K-5161
//Task 11

package com.lab_11.lab_11;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/greet")
public class GreetingController
{
    private final GreetingService greetingService;

    @Autowired
    public GreetingController(GreetingService greetingService)
    {
        this.greetingService = greetingService;
    }

    @GetMapping("/{name}")
    public String greetUser(
            @PathVariable String name,
            @RequestParam(defaultValue = "english") String language)
    {
        try
        {
            String greeting = greetingService.getGreeting(language);
            return greeting + ", " + name + "!";
        }

        catch (Exception e)
        {
            return "Error: Unsupported language requested. Please use 'english', 'french', or 'spanish'.";
        }
    }
}