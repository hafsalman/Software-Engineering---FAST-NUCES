package com.Task01.servlet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
@WebServlet(name = "Task_04", urlPatterns = "/task4")
public class Task_04 extends HttpServlet
{
    private static final long serialVersionUID = 1L;
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        String numberStr = request.getParameter("number");
        int number = Integer.parseInt(numberStr);

        List<Integer> fibonacciSequence = generateFibonacci(number);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Jaysha Iqbal, k22-5178: Task 04</h2>");
        out.println("<p>Fibonacci Sequence: " + fibonacciSequence.toString() + "</p>");
        out.println("</body></html>");
    }
    private List<Integer> generateFibonacci(int n)
    {
        List<Integer> sequence = new ArrayList<>();
        int a, b;

        a = 0;
        b = 1;

        while (a <= n)
        {
            sequence.add(a);
            int next = a + b;
            a = b;
            b = next;
        }

        return sequence;
    }
}