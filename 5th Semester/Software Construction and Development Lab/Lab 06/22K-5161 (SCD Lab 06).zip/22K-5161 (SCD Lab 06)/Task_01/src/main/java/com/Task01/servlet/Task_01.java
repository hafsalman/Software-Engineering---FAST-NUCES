package com.Task01.servlet;
    import java.io.IOException;
    import java.io.PrintWriter;
    import jakarta.servlet.ServletException;
    import jakarta.servlet.annotation.WebServlet;
    import jakarta.servlet.http.HttpServlet;
    import jakarta.servlet.http.HttpServletRequest;
    import jakarta.servlet.http.HttpServletResponse;

    @WebServlet(name = "Task_01", urlPatterns = "/task1")
    public class Task_01 extends HttpServlet
    {
        private static final long serialVersionUID = 1L;

        @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
        {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

            double num1 = Double.parseDouble(request.getParameter("number1"));
            double num2 = Double.parseDouble(request.getParameter("number2"));
            String operation = request.getParameter("operation");
            double result = 0;

            switch (operation)
            {
                case "+":
                {
                    result = num1 + num2;
                    break;
                }

                case "-":
                {
                    result = num1 - num2;
                    break;
                }

                case "*":
                {
                    result = num1 * num2;
                    break;
                }

                case "/":
                {
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                    }

                    else
                    {
                        out.println("<h2>Error: Number cannot be divided by zero</h2>");
                        return;
                    }
                    break;
                }

                default:
                {
                    out.println("<h2>Error: Invalid </h2>");
                    return;
                }
            }
            out.println("<h1>K22-5178, Jaysha Iqbal : Task no. 01</h1>");
            out.println("<h3>Result: " + result + "</3>");
            out.close();
        }
    }