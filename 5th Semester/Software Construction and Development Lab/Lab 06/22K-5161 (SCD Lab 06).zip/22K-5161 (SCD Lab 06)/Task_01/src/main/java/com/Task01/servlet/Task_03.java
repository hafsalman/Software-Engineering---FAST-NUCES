package com.Task01.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Task_03", urlPatterns = "/task3")
public class Task_03 extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException
    {
        String word = request.getParameter("word");
        String result;

        if (isPalindrome(word))
        {
            result = word + " is a palindrome.";
        }

        else
        {
            result = word + " is not a palindrome.";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>K22-5178: Task no. 03</h2>");
        out.println("<p>" + result + "</p>");
        out.println("</body></html>");
    }

    private boolean isPalindrome(String str)
    {
        String reversedStr = new StringBuilder(str).reverse().toString();
        return str.equalsIgnoreCase(reversedStr);
    }
}
