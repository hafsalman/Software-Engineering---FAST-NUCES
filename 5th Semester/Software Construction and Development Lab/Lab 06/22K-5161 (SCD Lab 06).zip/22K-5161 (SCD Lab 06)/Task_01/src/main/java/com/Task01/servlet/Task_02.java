
package com.Task01.servlet;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Task_02", urlPatterns = "/task2")
public class Task_02 extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        String temperatureStr = request.getParameter("temperature");
        String conversionType = request.getParameter("conversionType");

        double temperature = Double.parseDouble(temperatureStr);
        double convertedTemperature = 0.0;
        String result = "";

        if ("CF".equals(conversionType))
        {
            convertedTemperature = (temperature * 9/5) + 32;
            result = temperature + " °C = " + convertedTemperature + " °F";
        }

        else if ("FC".equals(conversionType))
        {
            convertedTemperature = (temperature - 32) * 5/9;
            result = temperature + " °F = " + convertedTemperature + " °C";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>K22-5178: Task no. 02</h2>");
        out.println("<p>" + result + "</p>");
        out.println("</body></html>");
    }
}