package com.Task01.servlet;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
@WebServlet(name = "Task_05", urlPatterns = "/task5")
public class Task_05 extends HttpServlet
{
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException
    {
        String inputString = request.getParameter("inputString");
        Map<Character, Integer> frequencyMap = countCharacterFrequencies(inputString);
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>K22-5178: Task no. 05</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Character</th><th>Frequency</th></tr>");
        for (Map.Entry<Character, Integer> entry : frequencyMap.entrySet())
        {
            out.println("<tr><td>" + entry.getKey() + "</td><td>" + entry.getValue() +
                    "</td></tr>");
        }
        out.println("</table>");
        out.println("</body></html>");
    }
    private Map<Character, Integer> countCharacterFrequencies(String str)
    {
        Map<Character, Integer> frequencyMap = new HashMap<>();
        for (char c : str.toCharArray())
        {
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
        }

        return frequencyMap;
    }
}