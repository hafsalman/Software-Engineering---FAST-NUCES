//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class Display_Task_01 extends JFrame
{
    public Display_Task_01(ArrayList<Books> BooksList)
    {
        setTitle("Book Library Management (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        String[] columnNames = {"Name", "Author", "ISBN"};

        Object[][] data = new Object[BooksList.size()][columnNames.length];

        for (int i = 0; i < BooksList.size(); i++)
        {
            Books book = BooksList.get(i);
            data[i][0] = book.name;
            data[i][1] = book.author;
            data[i][2] = book.ISBN;
        }

        DefaultTableModel model = new DefaultTableModel(data, columnNames);

        JTable table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
    }
}