//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Remove extends JFrame
{
    private JLabel Label;
    private JTextField textField1;
    private JButton removeButton;
    private JPanel RemoveISBN;

    public Remove(ArrayList<Books> BooksList)
    {
        setContentPane(RemoveISBN);
        setTitle("Book Library Management (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        removeButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String ISBN = textField1.getText();
                boolean found = false;

                for (int i = 0; i < BooksList.size(); i++)
                {
                    Books book = BooksList.get(i);

                    if (book.ISBN.equals(ISBN))
                    {
                        BooksList.remove(i);
                        JOptionPane.showMessageDialog(removeButton, "Book removed!");

                        found = true;

                        break;
                    }
                }

                if (found)
                {
                    new Display_Task_01(BooksList);
                    dispose();
                }

                else
                {
                    JOptionPane.showMessageDialog(removeButton, "No book found!");
                }
            }
        });
    }
}
