// Hafsa Salman
// 22K-5161
// Task no. 05

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;

public class DisplayTasks extends JFrame
{
    private JPanel Displaaaaaay;

    public DisplayTasks(ArrayList<String> List)
    {
        setContentPane(Displaaaaaay);
        setTitle("To-Do List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setLayout(new BorderLayout());

        String[] columnNames = {"Tasks"};

        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

        for (String task : List)
        {
            tableModel.addRow(new Object[]{task});
        }

        JTable taskTable = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(taskTable);

        add(scrollPane, BorderLayout.CENTER);
    }
}