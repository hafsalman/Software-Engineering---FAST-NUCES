//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class Task_02 extends JFrame
{
    private JPanel Task_02;
    private JButton addProductButton;
    private JLabel SCS;
    private JButton viewProductsButton;
    private JButton updateProductsButton;
    private JButton removeProductButton;
    private JButton totalPriceButton;

    public Task_02()
    {
        HashMap<String, Integer> Cart = new HashMap<>();
        Cart.put("Apples", 5);
        Cart.put("Bananas", 10);
        Cart.put("Detergent", 1);
        Cart.put("Knife", 2);

        HashMap<String, Double> PriceList = new HashMap<>();
        PriceList.put("Apples", 10.0);
        PriceList.put("Bananas", 7.0);
        PriceList.put("Detergent", 10.0);
        PriceList.put("Knife", 5.0);
        PriceList.put("Diapers", 15.0);
        PriceList.put("Milk", 10.0);
        PriceList.put("Pouch", 5.0);

        addProductButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new AddCart(Cart);
            }
        });

        viewProductsButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new ViewCart(Cart);
            }
        });

        updateProductsButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Update(Cart);
            }
        });

        removeProductButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new RemoveFromCart(Cart, PriceList);
            }
        });

        totalPriceButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new TotalPrice(Cart, PriceList);
            }
        });
    }

    public static void main(String[] args)
    {
        Task_02 T2 = new Task_02();

        T2.setContentPane(T2.Task_02);
        T2.setTitle("Shopping Cart System (22K-5161)");
        T2.setSize(500, 500);
        T2.setVisible(true);

        T2.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}