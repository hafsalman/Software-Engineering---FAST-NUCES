//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class SearchContactByPhone extends  JFrame
{
    private JLabel Label;
    private JLabel Phone;
    private JTextField textField1;
    private JButton searchButton;
    private JPanel SearchContact;

    public SearchContactByPhone(HashSet<Contacts> ContactsList)
    {
        setContentPane(SearchContact);
        setTitle("Contact List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        searchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String phone = textField1.getText();

                if (phone.isEmpty())
                {
                    JOptionPane.showMessageDialog(searchButton, "Please enter a name to search!");

                    return;
                }

                Contacts result = searchContactByPhone(phone, ContactsList);

                if (result != null)
                {
                    JOptionPane.showMessageDialog(searchButton, "Contact Found!\nName: " + result.getName() + "\nPhone: " + result.getPhoneNumber() + "\nEmail: " + result.getEmail(), "Contact Found", JOptionPane.INFORMATION_MESSAGE);
                }

                else
                {
                    JOptionPane.showMessageDialog(searchButton, "Contact not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private Contacts searchContactByPhone(String phone, HashSet<Contacts> ContactsList)
    {
        for (Contacts contact : ContactsList)
        {
            if (contact.getPhoneNumber().equals(phone))
            {
                return contact;
            }
        }
        return null;
    }
}
