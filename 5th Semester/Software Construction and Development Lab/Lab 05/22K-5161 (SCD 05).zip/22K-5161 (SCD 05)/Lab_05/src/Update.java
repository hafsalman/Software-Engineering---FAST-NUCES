//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class Update extends JFrame
{
    private JLabel Label;
    private JTextField textField1;
    private JButton updateButton;
    private JLabel Ugh;
    private JLabel quantityLabel;
    private JTextField textField2;
    private JPanel UPDATEEE;

    public Update(HashMap<String, Integer> Cart)
    {
        setContentPane(UPDATEEE);
        setTitle("Shopping Cart System (22K-5161)");
        setSize(500,500);
        setVisible(true);

        updateButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String productName = textField1.getText();
                int quantity = Integer.parseInt(textField2.getText());

                if (Cart.containsKey(productName))
                {
                    Cart.put(productName, quantity);

                    new ViewCart(Cart);
                }

                else
                {
                    JOptionPane.showMessageDialog(updateButton, "Product not found in cart.");
                }
            }
        });
    }
}