//Hafsa Salman
//22K-5161
//Task no. 05

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class AddTasks extends JFrame
{
    private JLabel Label;
    private JLabel Task;
    private JTextField textField1;
    private JButton addButton;
    private JPanel AddTasks;

    public AddTasks(ArrayList<String> List)
    {
        setContentPane(AddTasks);
        setTitle("To-Do List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        addButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String task = textField1.getText();

                List.add(task);

                new DisplayTasks(List);
            }
        });
    }
}