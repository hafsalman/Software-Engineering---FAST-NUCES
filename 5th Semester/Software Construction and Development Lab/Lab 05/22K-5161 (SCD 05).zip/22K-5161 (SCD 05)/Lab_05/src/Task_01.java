//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Task_01 extends JFrame
{
    private JPanel Task_01;
    private JButton Add;
    private JButton Display;
    private JButton Search01;
    private JButton Search02;
    private JButton Remove;
    private JLabel Label;

    public Task_01()
    {
        ArrayList<Books> BooksList = new ArrayList<Books>();

        Books newBook01 = new Books("The Thursday Murder Club", "Richard Osman", "123ABC");
        BooksList.add(newBook01);

        Books newBook02 = new Books("The Silent Patient", "Alex Michaelides", "456DEF");
        BooksList.add(newBook02);

        Books newBook03 = new Books("The Da Vinci Code", "Dan Brown", "ABCDEF");
        BooksList.add(newBook03);

        Add.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Add_Task_01(BooksList);
            }
        });

        Display.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Display_Task_01(BooksList);
            }
        });


        Search01.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new SearchByISBN(BooksList);
            }
        });


        Search02.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new SearchByTitle(BooksList);
            }
        });


        Remove.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Remove(BooksList);
            }
        });
    }

    public static void main(String[] args)
    {
        Task_01 T1 = new Task_01();

        T1.setContentPane(T1.Task_01);
        T1.setTitle("Book Library Management (22K-5161)");
        T1.setSize(500, 500);
        T1.setVisible(true);

        T1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

class Books
{
    String name;
    String author;
    String ISBN;

    public Books(String name, String author, String ISBN)
    {
        this.name = name;
        this.author = author;
        this.ISBN = ISBN;
    }
}