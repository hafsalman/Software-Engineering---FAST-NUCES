//Hafsa Salman
//22K-5161
//Task no. 05

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Task_05 extends JFrame
{
    private JPanel Task_05;
    private JLabel Label;
    private JButton addTaskButton;
    private JButton displayTasksButton;
    private JButton markAsCompletedButton;
    private JButton clearButton;

    public Task_05()
    {
        ArrayList <String> List = new ArrayList<>();

        List.add("SCD Lab 05");
        List.add("SCD Lab 06");
        List.add("DB Lab 06");
        List.add("DB Lab 07");
        List.add("SQE Assignment 01");

        addTaskButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new AddTasks(List);
            }
        });

        displayTasksButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new DisplayTasks(List);
            }
        });

        markAsCompletedButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new CompletedTasks(List);
            }
        });

        clearButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
               JOptionPane.showMessageDialog(clearButton, "Tasks Cleared!");
            }
        });
    }

    public static void main(String[] args)
    {
        Task_05 T5 = new Task_05();

        T5.setContentPane(T5.Task_05);
        T5.setTitle("To-Do List Application (22K-5161)");
        T5.setSize(500, 500);
        T5.setVisible(true);

        T5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}