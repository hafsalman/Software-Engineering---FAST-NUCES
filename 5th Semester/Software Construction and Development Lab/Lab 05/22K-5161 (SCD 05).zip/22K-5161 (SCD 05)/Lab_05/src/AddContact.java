// Hafsa Salman
// 22K-5161
// Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class AddContact extends JFrame
{
    private JPanel AddContact;
    private JLabel AC;
    private JLabel Whe;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JLabel Email;
    private JLabel Phone;
    private JButton addButton;

    public AddContact(HashSet<Contacts> ContactsList)
    {
        setContentPane(AddContact);
        setTitle("Contact List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        addButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String Name = textField1.getText().trim();
                String Phone = textField2.getText().trim();
                String Email = textField3.getText().trim();

                if (Name.isEmpty() || Phone.isEmpty() || Email.isEmpty())
                {
                    JOptionPane.showMessageDialog(addButton, "All fields must be filled!");
                }

                if (isDuplicate(Name, Phone, ContactsList))
                {
                    JOptionPane.showMessageDialog(addButton, "Contact with the same name or phone number already exists!");
                }

                else
                {
                    Contacts newContact = new Contacts(Name, Phone, Email);
                    ContactsList.add(newContact);

                    JOptionPane.showMessageDialog(addButton, "New contact added successfully!");

                    new DisplayContact(ContactsList);
                }
            }
        });
    }

    private boolean isDuplicate(String Name, String Phone, HashSet<Contacts> ContactsList)
    {
        for (Contacts contact : ContactsList)
        {
            if (contact.getName().equalsIgnoreCase(Name) || contact.getPhoneNumber().equals(Phone))
            {
                return true;
            }
        }

        return false;  // No duplicate
    }
}