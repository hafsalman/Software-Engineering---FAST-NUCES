//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.HashSet;

public class DisplayContact extends JFrame
{
    public DisplayContact(HashSet<Contacts> ContactsList)
    {

        setTitle("Contact List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setLayout(new BorderLayout());

        String[] columnNames = {"Name", "Phone Number", "Email"};

        Object[][] data = new Object[ContactsList.size()][3];

        int i = 0;

        for (Contacts contact : ContactsList)
        {
            data[i][0] = contact.getName();
            data[i][1] = contact.getPhoneNumber();
            data[i][2] = contact.getEmail();

            i++;
        }

        DefaultTableModel model = new DefaultTableModel(data, columnNames);

        JTable table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
    }
}