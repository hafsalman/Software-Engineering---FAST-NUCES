//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.HashMap;

public class ViewCart extends JFrame
{
    private JPanel View;

    public ViewCart(HashMap<String, Integer> Cart)
    {
        setContentPane(View);
        setTitle("Shopping Cart System (22K-5161)");
        setSize(500,500);
        setVisible(true);

        View.setLayout(new BorderLayout());

        String[] Columns = {"Product Names", "Quantity"};

        Object[][] data = new Object[Cart.size()][Columns.length];

        int i = 0;

        for (HashMap.Entry<String, Integer> entry : Cart.entrySet())
        {
            data[i][0] = entry.getKey();
            data[i][1] = entry.getValue();

            i++;
        }

        DefaultTableModel model = new DefaultTableModel(data, Columns);

        JTable table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
    }
}