//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Add_Task_01 extends JFrame
{
    private JLabel AddLabel;
    private JLabel Name;
    private JTextField BookName;
    private JLabel Author;
    private JTextField AuthorName;
    private JLabel Isbn;
    private JTextField BookISBN;
    private JButton AddBookBtn;
    private JPanel AddBooks;


    public Add_Task_01(ArrayList<Books> BooksList)
    {
        setContentPane(AddBooks);
        setTitle("Book Library Management (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        AddBookBtn.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String title = BookName.getText();
                String author = AuthorName.getText();
                String isbn = BookISBN.getText();

                if (title.isEmpty() || author.isEmpty() || isbn.isEmpty())
                {
                    JOptionPane.showMessageDialog(AddBookBtn, "Please Enter All Fields");
                }

                else
                {
                    Books newBooks = new Books(title, author, isbn);
                    BooksList.add(newBooks);

                    new Display_Task_01(BooksList);
                    dispose();
                }
            }
        });
    }
}