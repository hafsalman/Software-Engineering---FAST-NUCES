//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.util.Map;
import java.util.TreeMap;

public class Statistics extends JFrame
{
    private JPanel Stats;
    private JLabel Average;
    private JLabel Highest;
    private JLabel Lowest;

    public Statistics (TreeMap<String, Integer> Grades)
    {
        setContentPane(Stats);
        setTitle("Student Grading System (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        int sum = 0;
        int high = Integer.MIN_VALUE;
        int low = Integer.MAX_VALUE;

        for (Map.Entry<String, Integer> entry : Grades.entrySet())
        {
            int grade = entry.getValue();
            sum += grade;

            if (grade > high)
            {
                high = grade;
            }

            if (grade < low)
            {
                low = grade;
            }
        }

        double average = sum / (double) Grades.size();

        Average.setText("Class Average: " + String.format("%.2f", average));
        Highest.setText("Highest Grade: " + high);
        Lowest.setText("Lowest Grade: " + low);
    }
}