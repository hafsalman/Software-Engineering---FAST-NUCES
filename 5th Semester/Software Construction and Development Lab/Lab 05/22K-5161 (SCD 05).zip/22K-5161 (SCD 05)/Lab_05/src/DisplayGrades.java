//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Map;
import java.util.TreeMap;

public class DisplayGrades extends JFrame
{
    private JPanel Display;

    public DisplayGrades(TreeMap<String, Integer> Grades)
    {
        setContentPane(Display);
        setTitle("Student Grading System (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        setLayout(new BorderLayout());

        String[] columnNames = {"Student Name", "Grade"};

        Object[][] data = new Object[Grades.size()][2];

        int i = 0;

        for (Map.Entry<String, Integer> entry : Grades.entrySet())
        {
            data[i][0] = entry.getKey();
            data[i][1] = entry.getValue();
            i++;
        }

        DefaultTableModel model = new DefaultTableModel(data, columnNames);

        JTable table = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(table);

        add(scrollPane, BorderLayout.CENTER);
    }
}