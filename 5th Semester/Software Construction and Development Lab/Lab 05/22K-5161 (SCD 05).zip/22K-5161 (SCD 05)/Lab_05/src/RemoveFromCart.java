//Hafsa Salman
//22K-5161
//Task no.02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class RemoveFromCart extends JFrame
{
    private JPanel Remove;
    private JLabel Removeee;
    private JTextField textField1;
    private JButton removeButton;


    public RemoveFromCart(HashMap<String, Integer> Cart, HashMap<String, Double> PriceList)
    {
        setContentPane(Remove);
        setTitle("Shopping Cart System (22K-5161)");
        setSize(500,500);
        setVisible(true);

        removeButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String str = textField1.getText();

                if (Cart.containsKey(str))
                {
                    Cart.remove(str);
                    JOptionPane.showMessageDialog(removeButton, str + " has been removed from the cart.");
                    dispose();

                    new TotalPrice(Cart, PriceList);
                }

                else
                {
                    JOptionPane.showMessageDialog(removeButton, str + " is not in the cart.");
                }
            }
        });
    }
}