//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class Task_04 extends JFrame
{
    private JPanel Task_04;
    private JLabel Label;
    private JButton addContactButton;
    private JButton displayContactButton;
    private JButton searchByNameButton;
    private JButton searchByPhoneNumberButton;

    public Task_04()
    {
        HashSet<Contacts> ContactsList = new HashSet<>();

        Contacts contact01 = new Contacts("Hafsa", "03001234567", "hafsa@gmail.com");
        ContactsList.add(contact01);

        Contacts contact02 = new Contacts("Alizah", "03007654321", "alizah@gmail.com");
        ContactsList.add(contact02);

        Contacts contact03 = new Contacts("Amna", "03111111111", "amna@gmail.com");
        ContactsList.add(contact03);

        addContactButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new AddContact(ContactsList);
            }
        });

        displayContactButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new DisplayContact(ContactsList);
            }
        });

        searchByNameButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new SearchContactByName(ContactsList);
            }
        });

        searchByPhoneNumberButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new SearchContactByPhone(ContactsList);
            }
        });
    }

    public static void main(String[] args)
    {
        Task_04 T4 = new Task_04();

        T4.setContentPane(T4.Task_04);
        T4.setTitle("Contact List Application (22K-5161)");
        T4.setSize(500, 500);
        T4.setVisible(true);

        T4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}

class Contacts
{
    String name;
    String phone;
    String email;

    public Contacts (String name, String phone, String email)
    {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }

    public String getName()
    {
        return name;
    }

    public String getPhoneNumber()
    {
        return phone;
    }

    public String getEmail()
    {
        return email;
    }
}