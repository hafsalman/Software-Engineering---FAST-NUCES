//Hafsa Salman
//22K-5161
//Task no. 04

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashSet;

public class SearchContactByName extends JFrame
{
    private JLabel Whe;
    private JPanel SearchName;
    private JLabel Name;
    private JTextField textField1;
    private JButton searchButton;

    public SearchContactByName (HashSet<Contacts> ContactsList)
    {
        setContentPane(SearchName);
        setTitle("Contact List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        searchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String name = textField1.getText().trim();

                if (name.isEmpty())
                {
                    JOptionPane.showMessageDialog(searchButton, "Please enter a name to search!");

                    return;
                }

                Contacts result = searchContactByName(name, ContactsList);

                if (result != null)
                {
                    JOptionPane.showMessageDialog(searchButton, "Contact Found!\nName: " + result.getName() + "\nPhone: " + result.getPhoneNumber() + "\nEmail: " + result.getEmail(), "Contact Found", JOptionPane.INFORMATION_MESSAGE);
                }

                else
                {
                    JOptionPane.showMessageDialog(searchButton, "Contact not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
    }

    private Contacts searchContactByName(String name, HashSet<Contacts> ContactsList)
    {
        for (Contacts contact : ContactsList)
        {
            if (contact.getName().equalsIgnoreCase(name))
            {
                return contact;
            }
        }
        return null;
    }
}