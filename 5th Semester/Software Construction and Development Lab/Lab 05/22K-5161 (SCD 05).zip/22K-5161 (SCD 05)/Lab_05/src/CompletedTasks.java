//Hafsa Salman
//22K-5161
//Task no. 05

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class CompletedTasks extends JFrame
{
    private JLabel Label;
    private JPanel CompletedTasks;
    private JLabel Task;
    private JTextField textField1;
    private JButton markAsCompletedButton;

    public CompletedTasks(ArrayList<String> List)
    {
        setContentPane(CompletedTasks);
        setTitle("To-Do List Application (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        markAsCompletedButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String task = textField1.getText();

                for (String t : List)
                {
                    if (task.equals(t))
                    {
                        List.remove(t);

                        break;
                    }
                }

                new DisplayTasks(List);
            }
        });
    }
}