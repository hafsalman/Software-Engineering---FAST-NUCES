//Hafsa Salman
//22K-5161
//Task no. 02

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class AddCart extends JFrame
{
    private JLabel Label;
    private JTextField textField1;
    private JTextField textField2;
    private JButton addButton;
    private JPanel Adddd;

    public AddCart(HashMap<String, Integer> Cart)
    {
        setContentPane(Adddd);
        setTitle("Shopping Cart System (22K-5161)");
        setSize(500,500);
        setVisible(true);

        addButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String product = textField1.getText();
                int quantity = Integer.parseInt(textField2.getText());

                Cart.put(product, quantity);

                new ViewCart(Cart);
            }
        });
    }
}