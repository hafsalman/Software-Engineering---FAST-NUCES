//Hafsa Salman
//22K-5161
//Task no. 01

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class SearchByISBN extends JFrame
{
    private JTextField textField1;
    private JPanel SearchISBN;
    private JButton searchButton;
    private JLabel Search;

    public SearchByISBN(ArrayList<Books> BooksList)
    {
        setContentPane(SearchISBN);
        setTitle("Book Library Management (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        searchButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String ISBN = textField1.getText();
                boolean found = false;

                for (int i = 0; i < BooksList.size(); i++)
                {
                    Books book = BooksList.get(i);

                    if (book.ISBN.equals(ISBN))
                    {
                        JOptionPane.showMessageDialog(searchButton, "Book Found!\n" + "Title: " + book.name + "\n" + "Author: " + book.author + "\n" + "ISBN:" + book.ISBN);

                        found = true;

                        break;
                    }
                }

                if (!found)
                {
                    JOptionPane.showMessageDialog(searchButton, "No book found!");
                }
            }
        });
    }
}