//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;

public class Task_03 extends JFrame
{
    private JLabel T3;
    private JPanel Task_03;
    private JButton addStudentButton;
    private JButton displayStudentButton;
    private JButton classStatisticsButton;

    public Task_03()
    {
        TreeMap<String, Integer> Grades = new TreeMap<>();

        Grades.put("Hafsa", 99);
        Grades.put("Menahil", 87);
        Grades.put("Bia", 2);
        Grades.put("Ali", 67);

        addStudentButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new AddStudent(Grades);
            }
        });

        displayStudentButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new DisplayGrades(Grades);
            }
        });

        classStatisticsButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                new Statistics(Grades);
            }
        });
    }

    public static void main(String[] args)
    {
        Task_03 T3 = new Task_03();

        T3.setContentPane(T3.Task_03);
        T3.setTitle("Student Grading System (22K-5161)");
        T3.setSize(500, 500);
        T3.setVisible(true);

        T3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}