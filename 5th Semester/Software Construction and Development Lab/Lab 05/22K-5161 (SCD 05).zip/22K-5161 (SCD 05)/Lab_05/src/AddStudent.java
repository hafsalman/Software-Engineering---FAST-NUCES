//Hafsa Salman
//22K-5161
//Task no. 03

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.TreeMap;

public class AddStudent extends JFrame
{
    private JLabel Label;
    private JLabel Ugh;
    private JTextField textField1;
    private JTextField textField2;
    private JButton addButton;
    private JLabel gradeLabel;
    private JPanel AddGrade;

    public AddStudent(TreeMap<String, Integer> Grades)
    {
        setContentPane(AddGrade);
        setTitle("Student Grading System (22K-5161)");
        setSize(500, 500);
        setVisible(true);

        addButton.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                String name = textField1.getText();
                int grade = Integer.parseInt(textField2.getText());

                Grades.put(name, grade);

                new DisplayGrades(Grades);
            }
        });
    }
}